LayerKeySort generated C17 source package.
layerkeysort.h: public API; layerkeysort.c: implementation.
Also included: example.c, LICENSE, and this README.txt.
Copy the two layerkeysort files into your project and include
#include "layerkeysort.h" in your application.
GCC/Clang: cc -std=c17 -I. layerkeysort.c example.c -o example
MSVC Developer Command Prompt: cl /std:c17 /I. layerkeysort.c example.c
Replace example.c with your application source. Items remain caller-owned.
Documentation: https://github.com/RXY712200/LayerKeySort

简体中文
本包是从规范源码生成的 LayerKeySort C17 源码包。
layerkeysort.h 是公开 API，layerkeysort.c 是实现。
另含 example.c、LICENSE 和本 README.txt。
将两个 layerkeysort 文件复制到项目，在应用中包含
#include "layerkeysort.h"。
GCC/Clang：cc -std=c17 -I. layerkeysort.c example.c -o example
MSVC 开发人员命令提示符：cl /std:c17 /I. layerkeysort.c example.c
将 example.c 替换为应用源码。业务对象仍由调用者拥有。
文档：https://github.com/RXY712200/LayerKeySort
