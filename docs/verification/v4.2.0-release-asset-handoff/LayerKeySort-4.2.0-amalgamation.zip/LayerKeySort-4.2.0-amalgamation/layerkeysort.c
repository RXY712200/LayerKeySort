/* Generated from LayerKeySort's canonical C17 sources. Do not edit. */
#include "layerkeysort.h"

/* Begin private header: src/lks_alloc_internal.h */
#ifndef LKS_ALLOC_INTERNAL_H
#define LKS_ALLOC_INTERNAL_H

#include <stddef.h>

typedef enum LksAllocTag {
    LKS_ALLOC_TAG_OTHER = 0,
    LKS_ALLOC_TAG_PATH_OBJECT,
    LKS_ALLOC_TAG_PATH_STEPS,
    LKS_ALLOC_TAG_TREE_OBJECT,
    LKS_ALLOC_TAG_TREE_NODE,
    LKS_ALLOC_TAG_TREE_CHILDREN, /* historical ChildBlock diagnostics only */
    LKS_ALLOC_TAG_GROUP_OBJECT,
    LKS_ALLOC_TAG_GROUP_ORDERED,
    LKS_ALLOC_TAG_BATCH_OBJECT,
    LKS_ALLOC_TAG_BATCH_GROUP_ARRAY,
    LKS_ALLOC_TAG_MERGE_SCRATCH,
    LKS_ALLOC_TAG_COUNT
} LksAllocTag;

typedef struct LksAllocTagStats {
    size_t live_bytes;
    size_t peak_live_bytes;
    size_t live_blocks;
    size_t peak_live_blocks;
    size_t alloc_calls;
    size_t realloc_calls;
    size_t free_calls;
} LksAllocTagStats;

typedef struct LksAllocStats {
    size_t live_bytes;
    size_t peak_live_bytes;
    size_t live_blocks;
    /* Blocks at peak_live_bytes; max_live_blocks preserves the 8.1 high-water mark. */
    size_t peak_live_blocks;
    size_t max_live_blocks;
    size_t alloc_calls;
    size_t realloc_calls;
    size_t free_calls;
    size_t failed_calls;
    size_t total_successful_requested_bytes;
    int counter_overflowed;
    LksAllocTagStats tags[LKS_ALLOC_TAG_COUNT];
    size_t bytes_at_global_peak[LKS_ALLOC_TAG_COUNT];
    size_t blocks_at_global_peak[LKS_ALLOC_TAG_COUNT];
    size_t blocks_when_global_byte_peak;
} LksAllocStats;

void *lks_alloc(size_t size);
void *lks_alloc_tagged(size_t size, LksAllocTag tag);
void *lks_realloc(void *ptr, size_t size);
void lks_free(void *ptr);

/* Returns 0 on success, nonzero while LayerKeySort allocations remain live. */
int lks_alloc_stats_reset(void);
LksAllocStats lks_alloc_stats_get(void);

/* Private deterministic fault-injection controls for tests only. */
void lks_alloc_test_fail_on_attempt(size_t attempt_index);
void lks_alloc_test_disable_failure(void);
void lks_alloc_test_reset_attempt_counter(void);
size_t lks_alloc_test_get_attempt_count(void);
int lks_alloc_test_failure_triggered(void);

#endif /* LKS_ALLOC_INTERNAL_H */
/* End private header: src/lks_alloc_internal.h */

/* Begin private header: src/lks_legacy_internal.h */
#ifndef LKS_LEGACY_INTERNAL_H
#define LKS_LEGACY_INTERNAL_H
/* Private V3 migration/regression declarations. Never installed or supported
 * as V4 public API. The full legacy live engine is regression-only. */
/* bundled include: layerkeysort.h */
#define LKS_PATH_SLOT_MIN 0u
#define LKS_PATH_SLOT_MAX 65535u
#define LKS_STATUS_LEVEL_LIMIT ((LksStatus)4)
#define LKS_STATUS_NOT_IMPLEMENTED ((LksStatus)6)
/* Position direction around ZERO. */
typedef enum LksDirection {
    LKS_DIRECTION_ZERO = 0,
    LKS_DIRECTION_POSITIVE = 1,
    LKS_DIRECTION_NEGATIVE = -1
} LksDirection;

/* Opaque, re-encodable ordering coordinate, not a persistent item identity. */
typedef struct LksPath LksPath;


/* Create a ZERO Path. Caller owns the returned Path and destroys it with
 * lks_path_destroy; returns NULL if allocation fails. */
LksPath *lks_path_create_zero(void);
/* Create a one-step Path at level zero. Caller owns the result; NULL indicates
 * an invalid direction/slot or allocation failure. */
LksPath *lks_path_create(
    LksDirection direction,
    unsigned int first_slot
);
/* Create a one-step Path at an explicit level. Same ownership and failure
 * behavior as lks_path_create. */
LksPath *lks_path_create_at_level(
    LksDirection direction,
    unsigned int first_slot,
    size_t level
);
/* Deep-copy a Path. Caller owns the independent copy; NULL means invalid input
 * or allocation failure. Source is unchanged. */
LksPath *lks_path_clone(
    const LksPath *source
);
/* Append a step at the next level. On failure the Path remains unchanged. */
LksStatus lks_path_append(
    LksPath *path,
    unsigned int slot
);
/* Append a step at a strictly greater explicit level. On failure the Path is
 * unchanged; returns INVALID_ARGUMENT or OUT_OF_MEMORY. */
LksStatus lks_path_append_at_level(
    LksPath *path,
    unsigned int slot,
    size_t level
);
/* Read direction; NULL is treated as ZERO. */
LksDirection lks_path_direction(
    const LksPath *path
);
/* Read step count; NULL is treated as an empty Path. */
size_t lks_path_depth(
    const LksPath *path
);
/* Read a step slot into caller storage; invalid input/index returns
 * INVALID_ARGUMENT and leaves the output unchanged. */
LksStatus lks_path_get_slot(
    const LksPath *path,
    size_t index,
    unsigned int *out_slot
);
/* Read a step level into caller storage; invalid input/index returns
 * INVALID_ARGUMENT and leaves the output unchanged. */
LksStatus lks_path_get_level(
    const LksPath *path,
    size_t index,
    size_t *out_level
);
/* Destroy a caller-owned Path; NULL is accepted. */
void lks_path_destroy(
    LksPath *path
);
/* Return formatted character count excluding the terminator; zero means NULL
 * input or invalid internal Path state. */
size_t lks_path_text_length(
    const LksPath *path
);
/* Format into caller-owned storage without allocating. BUFFER_TOO_SMALL reports
 * insufficient capacity; the Path is never modified. Text is for display, not
 * persistent serialization or lexicographic replacement for Path comparison. */
LksStatus lks_path_format(
    const LksPath *path,
    char *buffer,
    size_t buffer_size
);
/* Parse exactly the canonical current display grammar. TEXT is borrowed;
 * success allocates a caller-owned Path. Failure leaves *OUT_PATH NULL. */
LksStatus lks_path_parse(const char *text, LksPath **out_path);
/* Versioned ASCII persistence key (LK1). Length excludes NUL; zero means
 * invalid input or unrepresentable length. Formatting allocates nothing.
 * Same-version canonical keys sort in Path order under bytewise strcmp. */
size_t lks_path_order_key_length(const LksPath *path);
LksStatus lks_path_order_key_format(const LksPath *path,
    char *buffer, size_t buffer_size);
/* KEY is borrowed. Success allocates a caller-owned Path; every failure sets
 * *OUT_PATH to NULL. Unsupported versions and noncanonical keys are invalid. */
LksStatus lks_path_order_key_parse(const char *key, LksPath **out_path);
/* Compare two positions and write a negative/zero/positive result on success.
 * Inputs are borrowed; output is unchanged on failure. */
LksStatus lks_path_compare(
    const LksPath *left,
    const LksPath *right,
    int *out_result
);
/* Allocate a valid position ordered before RIGHT. Caller owns *out_path on
 * success; output is set to NULL on failure. RIGHT is unchanged. */
LksStatus lks_path_before(
    const LksPath *right,
    LksPath **out_path
);
/* Allocate a valid position ordered after LEFT. Caller owns *out_path on
 * success; output is set to NULL on failure. LEFT is unchanged. */
LksStatus lks_path_after(
    const LksPath *left,
    LksPath **out_path
);

/* Opaque public Tree and read-only node view. Tree owns its nodes and cloned
 * Paths; item pointers remain borrowed. All borrowed Tree nodes, Paths, and
 * navigation results expire when the Tree actually mutates. An equal-Path
 * rekey succeeds without mutation and preserves borrowed observations. */
typedef struct LksTree LksTree;
typedef struct LksTreeNode LksTreeNode;
/* Comparator-bound online ordering container. Owns nodes and Paths, but
 * borrows items and comparator context. Keep comparator-relevant item fields
 * unchanged while resident: remove by exact Path, update, then reinsert.
 * Modifying them in place makes future comparator searches unreliable. */
typedef struct LksOrderedTree LksOrderedTree;
/* Opaque sorted collection. Group owns its structural storage, not its items. */
typedef struct LksLegacyGroup LksLegacyGroup;
/* Opaque collection of Groups. Batch owns its Groups, not the input items. */
typedef struct LksLegacyGroupBatch LksLegacyGroupBatch;

/* Build an independent sorted Group from borrowed item pointers. On success
 * caller owns *out_group and destroys it with lks_legacy_group_destroy. On failure
 * output is NULL and the input array/items are unchanged. */
LksStatus lks_legacy_group_build(
    void *const *items,
    size_t count,
    const LksComparator *comparator,
    LksLegacyGroup **out_group
);
/* Merge two sorted Groups into a new independent Group. Both inputs must have
 * been ordered under comparison semantics compatible with COMPARATOR,
 * including relevant context. Result Paths may be
 * reassigned, including Base Paths. Equal items from BASE
 * precede equal items from INCOMING; order within each source is preserved.
 * Inputs/items are borrowed and unchanged; caller owns the result. On failure
 * output is NULL and both inputs remain usable. */
LksStatus lks_legacy_group_merge(
    const LksLegacyGroup *base,
    const LksLegacyGroup *incoming,
    const LksComparator *comparator,
    LksLegacyGroup **out_group
);
/* Destroy a caller-owned Group; NULL is accepted. Does not destroy its items. */
void lks_legacy_group_destroy(LksLegacyGroup *group);
/* Return item count; NULL is treated as empty. */
size_t lks_legacy_group_size(const LksLegacyGroup *group);
/* Borrow an item pointer by sorted index; returns NULL for invalid input/index. */
void *lks_legacy_group_item_at(const LksLegacyGroup *group, size_t index);
/* Borrow a Group-owned Path, stable until the Group is destroyed.
 * Paths are local order coordinates, not persistent item identities. */
const LksPath *lks_legacy_group_path_at(const LksLegacyGroup *group, size_t index);

/* Build a Batch by splitting borrowed items into consecutive input chunks of
 * GROUP_SIZE and sorting each chunk. On success caller owns *out_batch; on
 * failure output is NULL and inputs/items are unchanged. */
LksStatus lks_legacy_group_batch_build(
    void *const *items,
    size_t count,
    size_t group_size,
    const LksComparator *comparator,
    LksLegacyGroupBatch **out_batch
);
/* Destroy a caller-owned Batch and its Groups; item pointers are not freed. */
void lks_legacy_group_batch_destroy(LksLegacyGroupBatch *batch);
/* Return total item count; NULL is treated as empty. */
size_t lks_legacy_group_batch_total_size(const LksLegacyGroupBatch *batch);
/* Return number of constituent Groups; NULL is treated as empty. */
size_t lks_legacy_group_batch_group_count(const LksLegacyGroupBatch *batch);
/* Return configured target size for each input chunk; NULL is treated as zero. */
size_t lks_legacy_group_batch_group_size(const LksLegacyGroupBatch *batch);
/* Borrow a Batch-owned Group, valid until the Batch is destroyed. */
const LksLegacyGroup *lks_legacy_group_batch_group_at(
    const LksLegacyGroupBatch *batch,
    size_t index
);
/* Merge all Batch Groups into a new independent Group. COMPARATOR must order
 * the constituent Groups compatibly with their build comparison semantics.
 * Caller owns the result;
 * Batch and its Groups remain unchanged. Equal items preserve source order.
 * On failure output is NULL and the Batch remains usable. */
LksStatus lks_legacy_group_batch_merge_all(
    const LksLegacyGroupBatch *batch,
    const LksComparator *comparator,
    LksLegacyGroup **out_group
);

/* Create an empty Tree. Caller owns it and destroys it with lks_tree_destroy;
 * returns NULL on allocation failure. */
LksTree *lks_tree_create(void);
/* Destroy a caller-owned Tree and its nodes/Paths; item pointers are not freed. */
void lks_tree_destroy(LksTree *tree);
/* Return node count; NULL is treated as empty. */
size_t lks_tree_size(const LksTree *tree);
/* Insert a unique explicit Path and borrowed item pointer. Tree clones PATH
 * without re-encoding it; no proper Path prefix needs to exist in the Tree.
 * Duplicate Paths return ALREADY_EXISTS. On success optional OUT_NODE borrows the inserted
 * node; earlier borrowed Tree observations must be reacquired. Failure leaves
 * the logical Tree unchanged and OUT_NODE NULL. */
LksStatus lks_tree_insert(
    LksTree *tree,
    const LksPath *path,
    void *item,
    const LksTreeNode **out_node
);
/* Find a node by Path; OUT_NODE borrows from TREE and is NULL on failure. */
LksStatus lks_tree_find_path(
    const LksTree *tree,
    const LksPath *path,
    const LksTreeNode **out_node
);
/* Remove one exact Path. TREE and PATH are borrowed; the Tree frees its node
 * and owned Path but never the caller-owned item. OUT_ITEM is optional and is
 * set to NULL on failure. No allocation or unrelated Path relabel occurs.
 * On success all earlier borrowed Tree observations must be reacquired. */
LksStatus lks_tree_remove_path(
    LksTree *tree,
    const LksPath *path,
    void **out_item
);
/* Move the same borrowed item from OLD_PATH to an unoccupied NEW_PATH.
 * Both inputs are borrowed. Failure, including allocation failure, leaves the
 * Tree unchanged and OUT_NODE NULL. Equal Paths succeed without mutation and
 * preserve earlier borrowed Tree observations.
 * A changed Path keeps Tree size fixed, normally changes only this item's
 * coordinate, and invalidates earlier borrowed Tree observations. */
LksStatus lks_tree_rekey(
    LksTree *tree,
    const LksPath *old_path,
    const LksPath *new_path,
    const LksTreeNode **out_node
);
/* Return a node-owned Path borrowed until the Tree changes or is destroyed.
 * A successful Tree mutation may re-encode existing Paths. */
const LksPath *lks_tree_node_path(const LksTreeNode *node);
/* Return the borrowed item pointer stored in a node; NULL node returns NULL. */
void *lks_tree_node_item(const LksTreeNode *node);
/* Physical index navigation is an ephemeral diagnostic view, not a logical
 * ordering traversal or a stable topology contract. It may change on an
 * actual mutation. A physical parent need not be a Path prefix; children
 * need not be logical Path descendants. Physical preorder is not Path order.
 * Compare Paths with lks_path_compare() for logical ordering. */
/* Return borrowed physical parent; the virtual root is reported as NULL. */
const LksTreeNode *lks_tree_node_parent(const LksTreeNode *node);
/* Return physical child count (currently at most two); NULL is zero. */
size_t lks_tree_node_child_count(const LksTreeNode *node);
/* Return borrowed physical child or NULL for an invalid index. When two
 * children exist, index 0 has the lower Path and index 1 the higher Path.
 * A sole child is returned at index 0. */
const LksTreeNode *lks_tree_node_child_at(
    const LksTreeNode *node,
    size_t index
);
/* Return virtual-root child count (zero when empty, one otherwise). */
size_t lks_tree_root_child_count(const LksTree *tree);
/* Return borrowed virtual-root child node or NULL for an invalid index. */
const LksTreeNode *lks_tree_root_child_at(
    const LksTree *tree,
    size_t index
);
/* Create an empty comparator-managed Tree. The descriptor is copied; callback
 * code and borrowed context must remain valid, deterministic, and compatible
 * with every resident item until this container is destroyed. The descriptor
 * object itself may go out of scope. Returns NULL on invalid input or OOM. */
LksOrderedTree *lks_ordered_tree_create(const LksComparator *comparator);
/* Destroy the container and its nodes/Paths, never the borrowed items or
 * comparator context. NULL is accepted. */
void lks_ordered_tree_destroy(LksOrderedTree *tree);
/* Return item count; NULL is treated as empty. */
size_t lks_ordered_tree_size(const LksOrderedTree *tree);
/* Stable upper-bound insertion: equal items follow earlier equal items.
 * Failure leaves all nodes and Paths unchanged and OUT_NODE NULL. Success
 * invalidates earlier borrowed node/Path/navigation observations. */
LksStatus lks_ordered_tree_insert(LksOrderedTree *tree, void *item,
    const LksTreeNode **out_node);
/* Locate first equal or the immediate neighbors under the bound comparator.
 * ITEM is a borrowed query and need not be resident. All three distinct
 * outputs are required and reset to NULL before searching. Returned nodes
 * have the same borrow lifetime as other Tree navigation results. */
LksStatus lks_ordered_tree_locate(const LksOrderedTree *tree,
    const void *item, const LksTreeNode **out_left,
    const LksTreeNode **out_equal, const LksTreeNode **out_right);
/* Exact coordinate lookup/removal does not invoke the item comparator.
 * Removal never frees the caller item, never re-encodes other Paths, and
 * invalidates earlier borrowed node/Path/navigation observations. A missing
 * Path leaves the container unchanged and optional OUT_ITEM NULL. */
LksStatus lks_ordered_tree_find_path(const LksOrderedTree *tree,
    const LksPath *path, const LksTreeNode **out_node);
LksStatus lks_ordered_tree_remove_path(LksOrderedTree *tree,
    const LksPath *path, void **out_item);
/* Physical index-root navigation; it is not logical Path order. Borrowed
 * results expire after an actual successful mutation or destruction. */
size_t lks_ordered_tree_root_child_count(const LksOrderedTree *tree);
const LksTreeNode *lks_ordered_tree_root_child_at(
    const LksOrderedTree *tree, size_t index);
/* Allocate a Path strictly between ordered LEFT and RIGHT. Caller owns the
 * result; output is NULL on failure and both inputs remain unchanged. */
LksStatus lks_path_between(
    const LksPath *left,
    const LksPath *right,
    LksPath **out_path
);


#endif
/* End private header: src/lks_legacy_internal.h */

/* Begin private header: src/lks_path_internal.h */
#ifndef LKS_PATH_INTERNAL_H
#define LKS_PATH_INTERNAL_H

#include <stddef.h>
/* bundled include: lks_legacy_internal.h */

/* Private read-only Path storage inspection for tests and benchmarks. */
size_t lks_path_internal_capacity(const LksPath *path);
size_t lks_path_internal_sizeof_path(void);
size_t lks_path_internal_alignof_path(void);
size_t lks_path_internal_storage_bytes(const LksPath *path);
size_t lks_path_internal_storage_bytes_for_capacity(size_t capacity);
size_t lks_path_internal_levels_offset_for_capacity(size_t capacity);

#endif /* LKS_PATH_INTERNAL_H */
/* End private header: src/lks_path_internal.h */

/* Begin private header: src/lks_slot_codec_internal.h */
#ifndef LKS_SLOT_CODEC_INTERNAL_H
#define LKS_SLOT_CODEC_INTERNAL_H

/* bundled include: layerkeysort.h */

enum { LKS_SLOT_TEXT_RADIX = 54, LKS_SLOT_TEXT_WIDTH = 3 };

/* Fixed-width, ASCII-ordered token. Returns zero for an out-of-range slot. */
int lks_slot_encode(unsigned int slot, char output[LKS_SLOT_TEXT_WIDTH]);
/* Decode one complete fixed-width token from the production alphabet. */
int lks_slot_decode(const char input[LKS_SLOT_TEXT_WIDTH], unsigned int *out_slot);

#endif
/* End private header: src/lks_slot_codec_internal.h */

/* Begin private header: src/lks_order_internal.h */
#ifndef LKS_ORDER_INTERNAL_H
#define LKS_ORDER_INTERNAL_H

/* bundled include: layerkeysort.h */
#include <stdint.h>
#include <limits.h>

/* Private policy, not a coordinate format or ABI guarantee. The extra pointer
 * slot is insertion scratch; committed occupancy never exceeds capacity. */
#ifndef LKS_ORDER_BLOCK_CAPACITY
#define LKS_ORDER_BLOCK_CAPACITY 64u
#endif
#define LKS_ORDER_BLOCK_MIN (LKS_ORDER_BLOCK_CAPACITY / 2u)
typedef struct LksOrderBlock LksOrderBlock;
typedef struct LksSourceMarker LksSourceMarker;
void lks_source_marker_release(LksSourceMarker *marker);
LksStatus lks_order_bulk_build(void *const *items, size_t count, LksOrder **out_order);

/* Owner is shared by the containing block; resident addresses never move. */
struct LksOrderHandle {
    LksOrderBlock *block;
    size_t local;
    void *item;
};

struct LksOrderBlock {
    LksOrder *owner;
    LksOrderBlock *left, *right, *parent;
    LksOrderBlock *previous, *next;
    size_t subtree_blocks, count;
    uint64_t tag;
    int height;
    LksOrderHandle *records[LKS_ORDER_BLOCK_CAPACITY + 1u];
};

#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
/* Per-operation diagnostics, deliberately absent from normal production.
 * 'index_blocks' counts distinct blocks whose index metadata/links are written,
 * not residents whose derived ranks changed. Tracking is diagnostic work only. */
#define LKS_ORDER_DIAG_TRACK_LIMIT (8u * (sizeof(size_t) * CHAR_BIT + 1u))
typedef struct LksOrderWork {
    size_t records_reassigned, local_blocks, index_blocks;
    size_t splits, redistributions, merges, rotations;
    size_t left_rotations, right_rotations;
    size_t left_right_rotations, right_left_rotations, two_child_detaches;
    size_t noop_moves, cross_block_moves;
    int tracking_overflow;
    const LksOrderBlock *tracked[LKS_ORDER_DIAG_TRACK_LIMIT];
} LksOrderWork;
#endif

struct LksOrder {
    LksOrderBlock *root, *first, *last;
    size_t count, blocks;
    uint64_t revision;
    int callback_active;
    LksSourceMarker *source_marker;
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
    LksOrderWork work;
    size_t tag_writes, tag_repairs, tag_fallbacks, max_tag_writes;
#endif
};

struct LksManagedOrder {
    LksOrder *core;
    LksComparator comparator;
    int active;
};

struct LksOrderCursor {
    const LksOrder *owner;
    const LksOrderHandle *next;
    uint64_t revision;
    int reverse;
};

#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
/* No allocation. Bounded recursion rejects cycles/excessive height before deep
 * descent. Checks index in-order against threads, record uniqueness/location,
 * occupancy and both public traversal directions. Not a dangling-pointer probe. */
int lks_order_internal_valid(const LksOrder *order);
#endif
#endif
/* End private header: src/lks_order_internal.h */

/* Begin private header: src/lks_snapshot_internal.h */
#ifndef LKS_SNAPSHOT_INTERNAL_H
#define LKS_SNAPSHOT_INTERNAL_H
/* bundled include: lks_order_internal.h */
typedef struct LksSnapshotRow { size_t end; } LksSnapshotRow;
struct LksSnapshot {
    LksSnapshotRow *rows;
    unsigned char *namespace_data, *associations;
    size_t count, namespace_size, association_size, association_capacity;
    LksSourceMarker *marker;
    uint64_t revision;
};
/* Rows hold cumulative ends: repeated ends represent empty associations.
 * Header, rows and namespace share one allocation; association bytes stay
 * separately growable until publication. Unpublished rows need no zero fill. */
static inline size_t lks_snapshot_row_offset(const LksSnapshot *s, size_t row)
{ return row ? s->rows[row-1].end : 0; }
static inline size_t lks_snapshot_row_size(const LksSnapshot *s, size_t row)
{ return s->rows[row].end-lks_snapshot_row_offset(s, row); }
LksStatus lks_snapshot_new(size_t count, const void *domain, size_t domain_size,
    LksSnapshot **out);
/* Private traversal adapter: one next-item call per occurrence, no rank search. */
typedef void *(*LksSnapshotNextItem)(void *iterator);
LksStatus lks_snapshot_capture_sequence(size_t count, LksSnapshotNextItem next,
    void *iterator, int *busy, LksSourceMarker **marker, uint64_t revision,
    const LksSnapshotOptions *options, LksSnapshot **out);
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
/* Private capacity boundary injection, only with externally serialized tests. */
void lks_source_marker_test_refs(LksSourceMarker *marker, size_t refs);
#endif
#endif
/* End private header: src/lks_snapshot_internal.h */

/* Begin private header: src/lks_immutable_group_internal.h */
#ifndef LKS_IMMUTABLE_GROUP_INTERNAL_H
#define LKS_IMMUTABLE_GROUP_INTERNAL_H
/* bundled include: layerkeysort.h */
typedef struct LksSourceMarker LksSourceMarker;
struct LksGroup {
    void **items;
    size_t count;
    LksSourceMarker *marker;
    int busy;
};
struct LksGroupBatch {
    LksGroup **groups;
    size_t count, group_count, group_size;
    int busy;
};
#endif
/* End private header: src/lks_immutable_group_internal.h */

/* Begin private header: src/lks_sort_internal.h */
#ifndef LKS_SORT_INTERNAL_H
#define LKS_SORT_INTERNAL_H

/* bundled include: layerkeysort.h */

LksStatus lks_stable_sort_copy(void *const *items, size_t count,
    const LksComparator *comparator, void ***out_sorted);
void lks_merge_sorted_pointers(void *const *left, size_t left_count,
    void *const *right, size_t right_count, const LksComparator *comparator,
    void **output);

#endif
/* End private header: src/lks_sort_internal.h */

/* Begin production source: src/lks_alloc.c */
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
/* bundled include: lks_alloc_internal.h */

#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS

#if defined(_MSC_VER)
/* MSVC's C17 headers do not expose max_align_t; use fundamental C types. */
typedef union LksMaxAlignmentFallback {
    long double long_double_value;
    long long long_long_value;
    void *pointer_value;
} LksMaxAlignmentFallback;
#define LKS_ALLOC_MAX_ALIGNMENT LksMaxAlignmentFallback
#else
#define LKS_ALLOC_MAX_ALIGNMENT max_align_t
#endif

typedef union LksAllocHeader {
    struct {
        size_t requested_size;
        LksAllocTag tag;
    } data;
    LKS_ALLOC_MAX_ALIGNMENT alignment;
} LksAllocHeader;

static LksAllocStats lks_alloc_stats;
static size_t lks_alloc_test_attempt_count;
static size_t lks_alloc_test_fail_index;
static int lks_alloc_test_triggered;

void lks_alloc_test_fail_on_attempt(size_t attempt_index)
{
    if (attempt_index == 0) {
        lks_alloc_test_disable_failure();
        return;
    }
    lks_alloc_test_attempt_count = 0;
    lks_alloc_test_fail_index = attempt_index;
    lks_alloc_test_triggered = 0;
}

void lks_alloc_test_disable_failure(void)
{
    lks_alloc_test_attempt_count = 0;
    lks_alloc_test_fail_index = 0;
    lks_alloc_test_triggered = 0;
}

void lks_alloc_test_reset_attempt_counter(void)
{
    lks_alloc_test_attempt_count = 0;
}

size_t lks_alloc_test_get_attempt_count(void)
{
    return lks_alloc_test_attempt_count;
}

int lks_alloc_test_failure_triggered(void)
{
    return lks_alloc_test_triggered;
}

static int lks_alloc_test_should_fail(void)
{
    if (lks_alloc_test_attempt_count != (size_t)-1)
        ++lks_alloc_test_attempt_count;
    if (lks_alloc_test_fail_index == 0 || lks_alloc_test_triggered)
        return 0;
    if (lks_alloc_test_attempt_count == lks_alloc_test_fail_index) {
        lks_alloc_test_triggered = 1;
        return 1;
    }
    return 0;
}

static LksAllocTag lks_alloc_normalize_tag(LksAllocTag tag)
{
    return tag >= LKS_ALLOC_TAG_OTHER && tag < LKS_ALLOC_TAG_COUNT ?
        tag : LKS_ALLOC_TAG_OTHER;
}

static void lks_alloc_counter_add(size_t *counter, size_t amount)
{
    if (*counter > (size_t)-1 - amount) {
        *counter = (size_t)-1;
        lks_alloc_stats.counter_overflowed = 1;
    } else {
        *counter += amount;
    }
}

static void lks_alloc_failed(LksAllocTag tag)
{
    lks_alloc_counter_add(&lks_alloc_stats.failed_calls, 1);
    (void)tag;
}

static void lks_alloc_capture_global_peak(void)
{
    size_t tag;
    if (lks_alloc_stats.live_bytes <= lks_alloc_stats.peak_live_bytes) return;
    lks_alloc_stats.peak_live_bytes = lks_alloc_stats.live_bytes;
    lks_alloc_stats.peak_live_blocks = lks_alloc_stats.live_blocks;
    lks_alloc_stats.blocks_when_global_byte_peak = lks_alloc_stats.live_blocks;
    for (tag = 0; tag < LKS_ALLOC_TAG_COUNT; ++tag) {
        lks_alloc_stats.bytes_at_global_peak[tag] =
            lks_alloc_stats.tags[tag].live_bytes;
        lks_alloc_stats.blocks_at_global_peak[tag] =
            lks_alloc_stats.tags[tag].live_blocks;
    }
}

static void lks_alloc_live_add(LksAllocTag tag, size_t bytes, size_t blocks)
{
    LksAllocTagStats *tag_stats = &lks_alloc_stats.tags[tag];
    lks_alloc_counter_add(&lks_alloc_stats.live_bytes, bytes);
    lks_alloc_counter_add(&lks_alloc_stats.live_blocks, blocks);
    lks_alloc_counter_add(&tag_stats->live_bytes, bytes);
    lks_alloc_counter_add(&tag_stats->live_blocks, blocks);
    if (tag_stats->live_bytes > tag_stats->peak_live_bytes)
        tag_stats->peak_live_bytes = tag_stats->live_bytes;
    if (tag_stats->live_blocks > tag_stats->peak_live_blocks)
        tag_stats->peak_live_blocks = tag_stats->live_blocks;
    if (lks_alloc_stats.live_blocks > lks_alloc_stats.max_live_blocks)
        lks_alloc_stats.max_live_blocks = lks_alloc_stats.live_blocks;
    lks_alloc_capture_global_peak();
}

static void lks_alloc_live_resize(LksAllocTag tag, size_t old_size,
    size_t new_size)
{
    LksAllocTagStats *tag_stats = &lks_alloc_stats.tags[tag];
    if (new_size > old_size) {
        size_t increase = new_size - old_size;
        lks_alloc_counter_add(&lks_alloc_stats.live_bytes, increase);
        lks_alloc_counter_add(&tag_stats->live_bytes, increase);
        if (tag_stats->live_bytes > tag_stats->peak_live_bytes)
            tag_stats->peak_live_bytes = tag_stats->live_bytes;
        lks_alloc_capture_global_peak();
    } else {
        size_t decrease = old_size - new_size;
        if (lks_alloc_stats.live_bytes >= decrease)
            lks_alloc_stats.live_bytes -= decrease;
        else {
            lks_alloc_stats.live_bytes = 0;
            lks_alloc_stats.counter_overflowed = 1;
        }
        if (tag_stats->live_bytes >= decrease)
            tag_stats->live_bytes -= decrease;
        else {
            tag_stats->live_bytes = 0;
            lks_alloc_stats.counter_overflowed = 1;
        }
    }
}

static void *lks_alloc_new(size_t size, int count_alloc_call, LksAllocTag tag,
    int count_attempt)
{
    LksAllocHeader *header;
    size_t total_size;
    LksAllocTagStats *tag_stats;

    tag = lks_alloc_normalize_tag(tag);
    tag_stats = &lks_alloc_stats.tags[tag];
    if (count_alloc_call) {
        lks_alloc_counter_add(&lks_alloc_stats.alloc_calls, 1);
        lks_alloc_counter_add(&tag_stats->alloc_calls, 1);
    }
    if (count_attempt && lks_alloc_test_should_fail()) {
        lks_alloc_failed(tag);
        return NULL;
    }
    if (size > (size_t)-1 - sizeof(*header)) {
        lks_alloc_failed(tag);
        return NULL;
    }
    total_size = sizeof(*header) + size;
    header = (LksAllocHeader *)malloc(total_size);
    if (header == NULL) {
        lks_alloc_failed(tag);
        return NULL;
    }
    header->data.requested_size = size;
    header->data.tag = tag;
    lks_alloc_live_add(tag, size, 1);
    lks_alloc_counter_add(&lks_alloc_stats.total_successful_requested_bytes,
        size);
    return (void *)(header + 1);
}

static void lks_alloc_release(void *ptr, int count_free_call)
{
    LksAllocHeader *header;
    LksAllocTag tag;
    LksAllocTagStats *tag_stats;
    size_t old_size;

    if (ptr == NULL) return;
    header = ((LksAllocHeader *)ptr) - 1;
    old_size = header->data.requested_size;
    tag = lks_alloc_normalize_tag(header->data.tag);
    tag_stats = &lks_alloc_stats.tags[tag];
    if (lks_alloc_stats.live_bytes >= old_size)
        lks_alloc_stats.live_bytes -= old_size;
    else {
        lks_alloc_stats.live_bytes = 0;
        lks_alloc_stats.counter_overflowed = 1;
    }
    if (tag_stats->live_bytes >= old_size)
        tag_stats->live_bytes -= old_size;
    else {
        tag_stats->live_bytes = 0;
        lks_alloc_stats.counter_overflowed = 1;
    }
    if (lks_alloc_stats.live_blocks > 0) --lks_alloc_stats.live_blocks;
    else lks_alloc_stats.counter_overflowed = 1;
    if (tag_stats->live_blocks > 0) --tag_stats->live_blocks;
    else lks_alloc_stats.counter_overflowed = 1;
    if (count_free_call) {
        lks_alloc_counter_add(&lks_alloc_stats.free_calls, 1);
        lks_alloc_counter_add(&tag_stats->free_calls, 1);
    }
    free(header);
}

void *lks_alloc(size_t size)
{
    return lks_alloc_tagged(size, LKS_ALLOC_TAG_OTHER);
}

void *lks_alloc_tagged(size_t size, LksAllocTag tag)
{
    return lks_alloc_new(size, 1, lks_alloc_normalize_tag(tag), 1);
}

void *lks_realloc(void *ptr, size_t size)
{
    LksAllocHeader *old_header;
    LksAllocHeader *new_header;
    LksAllocTag tag;
    LksAllocTagStats *tag_stats;
    size_t old_size;
    size_t new_total_size;

    if (ptr == NULL) {
        lks_alloc_counter_add(&lks_alloc_stats.realloc_calls, 1);
        lks_alloc_counter_add(&lks_alloc_stats.tags[LKS_ALLOC_TAG_OTHER].realloc_calls, 1);
        return lks_alloc_new(size, 0, LKS_ALLOC_TAG_OTHER, size > 0);
    }
    old_header = ((LksAllocHeader *)ptr) - 1;
    tag = lks_alloc_normalize_tag(old_header->data.tag);
    tag_stats = &lks_alloc_stats.tags[tag];
    lks_alloc_counter_add(&lks_alloc_stats.realloc_calls, 1);
    lks_alloc_counter_add(&tag_stats->realloc_calls, 1);
    if (size == 0) {
        lks_alloc_release(ptr, 0);
        return NULL;
    }
    if (lks_alloc_test_should_fail()) {
        lks_alloc_failed(tag);
        return NULL;
    }
    if (size > (size_t)-1 - sizeof(*old_header)) {
        lks_alloc_failed(tag);
        return NULL;
    }
    old_size = old_header->data.requested_size;
    new_total_size = sizeof(*old_header) + size;
    new_header = (LksAllocHeader *)realloc(old_header, new_total_size);
    if (new_header == NULL) {
        lks_alloc_failed(tag);
        return NULL;
    }
    new_header->data.requested_size = size;
    new_header->data.tag = tag;
    lks_alloc_live_resize(tag, old_size, size);
    lks_alloc_counter_add(&lks_alloc_stats.total_successful_requested_bytes,
        size);
    return (void *)(new_header + 1);
}

void lks_free(void *ptr)
{
    lks_alloc_release(ptr, 1);
}

int lks_alloc_stats_reset(void)
{
    if (lks_alloc_stats.live_blocks != 0 || lks_alloc_stats.live_bytes != 0)
        return 1;
    lks_alloc_stats = (LksAllocStats){ 0 };
    return 0;
}

LksAllocStats lks_alloc_stats_get(void)
{
    return lks_alloc_stats;
}

#else

/* Production allocations have no shared mutable diagnostic state. malloc
 * already supplies fundamental alignment; tests use the instrumented build. */
void *lks_alloc(size_t size) { return malloc(size == 0 ? 1 : size); }
void *lks_alloc_tagged(size_t size, LksAllocTag tag)
{ (void)tag; return lks_alloc(size); }
void *lks_realloc(void *ptr, size_t size)
{
    if (ptr == NULL) return lks_alloc(size);
    if (size == 0) { free(ptr); return NULL; }
    return realloc(ptr, size);
}
void lks_free(void *ptr) { free(ptr); }
int lks_alloc_stats_reset(void) { return 0; }
LksAllocStats lks_alloc_stats_get(void) { LksAllocStats stats = {0}; return stats; }
void lks_alloc_test_fail_on_attempt(size_t index) { (void)index; }
void lks_alloc_test_disable_failure(void) { }
void lks_alloc_test_reset_attempt_counter(void) { }
size_t lks_alloc_test_get_attempt_count(void) { return 0; }
int lks_alloc_test_failure_triggered(void) { return 0; }

#endif
/* End production source: src/lks_alloc.c */

/* Begin production source: src/lks_base.c */
/* bundled include: layerkeysort.h */

const char *lks_status_string(LksStatus status)
{
    switch (status) {
    case LKS_STATUS_OK:
        return "OK";
    case LKS_STATUS_INVALID_ARGUMENT:
        return "Invalid argument";
    case LKS_STATUS_OUT_OF_MEMORY:
        return "Out of memory";
    case LKS_STATUS_BUFFER_TOO_SMALL:
        return "Buffer too small";
    case LKS_STATUS_ALREADY_EXISTS:
        return "Already exists";
    case LKS_STATUS_NOT_FOUND:
        return "Not found";
    case LKS_STATUS_INTERNAL_ERROR:
        return "Internal error";
    case LKS_STATUS_CAPACITY_LIMIT:
        return "Capacity limit reached";
    case LKS_STATUS_INVALIDATED:
        return "Cursor invalidated";
    case LKS_STATUS_REENTRANT:
        return "Reentrant access rejected";
    case LKS_STATUS_DOMAIN_MISMATCH:
        return "Snapshot key domain mismatch";
    default:
        return "Unknown status";
    }
}
/* End production source: src/lks_base.c */

/* Begin production source: src/path.c */
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
/* bundled include: lks_legacy_internal.h */
/* bundled include: lks_alloc_internal.h */
/* bundled include: lks_path_internal.h */

_Static_assert(LKS_PATH_SLOT_MIN == 0u && LKS_PATH_SLOT_MAX == UINT16_MAX,
    "Path slot range must match uint16_t storage");

/* A Path is a re-encodable ordering coordinate. Its slot and level arrays
 * share one allocation, so internal storage stays linear in depth; the
 * formatted display text is never stored here. */
struct LksPath {
    LksDirection direction;
    unsigned char *storage;
    size_t depth;
    size_t capacity;
};

/* The public unsigned-int slot arguments preserve the API shape. Constructors
 * and append operations check LKS_PATH_SLOT_MAX before narrowing to uint16_t.
 * Using every representable slot delays same-level congestion without growing
 * the existing 16-bit per-step storage. */

static LksStatus path_storage_layout(size_t capacity, size_t *levels_offset,
    size_t *total_bytes)
{
    size_t slot_bytes, level_bytes, alignment, remainder, padding, offset;
    if (levels_offset == NULL || total_bytes == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    *levels_offset = 0;
    *total_bytes = 0;
    if (capacity == 0) return LKS_STATUS_OK;
    if (capacity > (size_t)-1 / sizeof(uint16_t) ||
        capacity > (size_t)-1 / sizeof(size_t)) return LKS_STATUS_OUT_OF_MEMORY;
    slot_bytes = capacity * sizeof(uint16_t);
    level_bytes = capacity * sizeof(size_t);
    alignment = _Alignof(size_t);
    if (alignment == 0) return LKS_STATUS_OUT_OF_MEMORY;
    remainder = slot_bytes % alignment;
    padding = remainder == 0 ? 0 : alignment - remainder;
    if (slot_bytes > (size_t)-1 - padding) return LKS_STATUS_OUT_OF_MEMORY;
    offset = slot_bytes + padding;
    if (offset > (size_t)-1 - level_bytes) return LKS_STATUS_OUT_OF_MEMORY;
    *levels_offset = offset;
    *total_bytes = offset + level_bytes;
    return LKS_STATUS_OK;
}

static uint16_t *path_slots(LksPath *path)
{
    return path == NULL || path->storage == NULL ? NULL : (uint16_t *)(void *)path->storage;
}

static const uint16_t *path_slots_const(const LksPath *path)
{
    return path == NULL || path->storage == NULL ? NULL : (const uint16_t *)(const void *)path->storage;
}

static size_t *path_levels(LksPath *path)
{
    size_t offset, total;
    if (path == NULL || path->storage == NULL ||
        path_storage_layout(path->capacity, &offset, &total) != LKS_STATUS_OK) return NULL;
    (void)total;
    return (size_t *)(void *)(path->storage + offset);
}

static const size_t *path_levels_const(const LksPath *path)
{
    size_t offset, total;
    if (path == NULL || path->storage == NULL ||
        path_storage_layout(path->capacity, &offset, &total) != LKS_STATUS_OK) return NULL;
    (void)total;
    return (const size_t *)(const void *)(path->storage + offset);
}

size_t lks_path_internal_capacity(const LksPath *path)
{
    return path == NULL ? 0 : path->capacity;
}

size_t lks_path_internal_sizeof_path(void) { return sizeof(LksPath); }
size_t lks_path_internal_alignof_path(void) { return _Alignof(LksPath); }

size_t lks_path_internal_storage_bytes_for_capacity(size_t capacity)
{
    size_t offset, total;
    return path_storage_layout(capacity, &offset, &total) == LKS_STATUS_OK ? total : (size_t)-1;
}

size_t lks_path_internal_levels_offset_for_capacity(size_t capacity)
{
    size_t offset, total;
    return path_storage_layout(capacity, &offset, &total) == LKS_STATUS_OK ? offset : (size_t)-1;
}

size_t lks_path_internal_storage_bytes(const LksPath *path)
{
    return path == NULL ? 0 : lks_path_internal_storage_bytes_for_capacity(path->capacity);
}

static LksStatus lks_path_reserve_one(LksPath *path)
{
    size_t required_capacity, new_capacity, old_offset, old_total, new_offset, new_total;
    unsigned char *new_storage;
    LksStatus status;
    if (path->depth == (size_t)-1) return LKS_STATUS_OUT_OF_MEMORY;
    required_capacity = path->depth + 1;
    if (required_capacity <= path->capacity) return LKS_STATUS_OK;
    new_capacity = path->capacity == 0 ? 1 : path->capacity;
    while (new_capacity < required_capacity) {
        if (new_capacity > (size_t)-1 / 2) { new_capacity = required_capacity; break; }
        new_capacity *= 2;
    }
    status = path_storage_layout(path->capacity, &old_offset, &old_total);
    if (status != LKS_STATUS_OK) return status;
    status = path_storage_layout(new_capacity, &new_offset, &new_total);
    if (status != LKS_STATUS_OK) return status;
    new_storage = (unsigned char *)lks_realloc(path->storage, new_total);
    if (new_storage == NULL) return LKS_STATUS_OUT_OF_MEMORY;
    if (path->depth > 0 && old_offset != new_offset) {
        memmove(new_storage + new_offset, new_storage + old_offset,
            path->depth * sizeof(size_t));
    }
    path->storage = new_storage;
    path->capacity = new_capacity;
    (void)old_total;
    return LKS_STATUS_OK;
}

LksPath *lks_path_create_zero(void)
{
    LksPath *path = (LksPath *)lks_alloc_tagged(sizeof(*path), LKS_ALLOC_TAG_PATH_OBJECT);
    if (path == NULL) return NULL;
    path->direction = LKS_DIRECTION_ZERO;
    path->storage = NULL;
    path->depth = 0;
    path->capacity = 0;
    return path;
}

LksPath *lks_path_create(LksDirection direction, unsigned int first_slot)
{
    return lks_path_create_at_level(direction, first_slot, 0);
}

LksPath *lks_path_create_at_level(LksDirection direction, unsigned int first_slot, size_t level)
{
    LksPath *path;
    size_t offset, bytes;
    if ((direction != LKS_DIRECTION_POSITIVE && direction != LKS_DIRECTION_NEGATIVE) ||
        first_slot > LKS_PATH_SLOT_MAX ||
        path_storage_layout(1, &offset, &bytes) != LKS_STATUS_OK) return NULL;
    path = (LksPath *)lks_alloc_tagged(sizeof(*path), LKS_ALLOC_TAG_PATH_OBJECT);
    if (path == NULL) return NULL;
    path->storage = (unsigned char *)lks_alloc_tagged(bytes, LKS_ALLOC_TAG_PATH_STEPS);
    if (path->storage == NULL) { lks_free(path); return NULL; }
    path->direction = direction;
    path->depth = 1;
    path->capacity = 1;
    path_slots(path)[0] = (uint16_t)first_slot;
    path_levels(path)[0] = level;
    return path;
}

LksPath *lks_path_clone(const LksPath *source)
{
    LksPath *copy;
    size_t offset, bytes;
    if (source == NULL) return NULL;
    copy = (LksPath *)lks_alloc_tagged(sizeof(*copy), LKS_ALLOC_TAG_PATH_OBJECT);
    if (copy == NULL) return NULL;
    copy->direction = source->direction;
    copy->storage = NULL;
    copy->depth = source->depth;
    copy->capacity = source->depth;
    if (source->depth > 0) {
        if (path_storage_layout(source->depth, &offset, &bytes) != LKS_STATUS_OK) {
            lks_free(copy); return NULL;
        }
        copy->storage = (unsigned char *)lks_alloc_tagged(bytes, LKS_ALLOC_TAG_PATH_STEPS);
        if (copy->storage == NULL) { lks_free(copy); return NULL; }
        memcpy(path_slots(copy), path_slots_const(source), source->depth * sizeof(uint16_t));
        memcpy(path_levels(copy), path_levels_const(source), source->depth * sizeof(size_t));
    }
    (void)offset;
    return copy;
}

LksStatus lks_path_append_at_level(LksPath *path, unsigned int slot, size_t level)
{
    LksStatus status;
    size_t depth;
    if (path == NULL || path->direction == LKS_DIRECTION_ZERO ||
        slot > LKS_PATH_SLOT_MAX || path->depth == 0 ||
        level <= path_levels(path)[path->depth - 1]) return LKS_STATUS_INVALID_ARGUMENT;
    status = lks_path_reserve_one(path);
    if (status != LKS_STATUS_OK) return status;
    depth = path->depth;
    path_slots(path)[depth] = (uint16_t)slot;
    path_levels(path)[depth] = level;
    ++path->depth;
    return LKS_STATUS_OK;
}

LksStatus lks_path_append(LksPath *path, unsigned int slot)
{
    size_t last_level;
    if (path == NULL || path->direction == LKS_DIRECTION_ZERO ||
        slot > LKS_PATH_SLOT_MAX || path->depth == 0)
        return LKS_STATUS_INVALID_ARGUMENT;
    last_level = path_levels(path)[path->depth - 1];
    if (last_level == (size_t)-1) return LKS_STATUS_INVALID_ARGUMENT;
    return lks_path_append_at_level(path, slot, last_level + 1);
}

LksDirection lks_path_direction(const LksPath *path) { return path == NULL ? LKS_DIRECTION_ZERO : path->direction; }
size_t lks_path_depth(const LksPath *path) { return path == NULL ? 0 : path->depth; }

LksStatus lks_path_get_slot(const LksPath *path, size_t index, unsigned int *out_slot)
{
    if (path == NULL || out_slot == NULL || index >= path->depth) return LKS_STATUS_INVALID_ARGUMENT;
    *out_slot = (unsigned int)path_slots_const(path)[index];
    return LKS_STATUS_OK;
}

LksStatus lks_path_get_level(const LksPath *path, size_t index, size_t *out_level)
{
    if (path == NULL || out_level == NULL || index >= path->depth) return LKS_STATUS_INVALID_ARGUMENT;
    *out_level = path_levels_const(path)[index];
    return LKS_STATUS_OK;
}

void lks_path_destroy(LksPath *path)
{
    if (path == NULL) return;
    lks_free(path->storage);
    lks_free(path);
}
/* End production source: src/path.c */

/* Begin production source: src/path_text.c */
/* bundled include: lks_legacy_internal.h */
/* bundled include: lks_slot_codec_internal.h */
#include <stdint.h>
#include <string.h>

static const char zero_path_text[] = "000";

static size_t decimal_digits(size_t value)
{
    size_t digits = 1;
    while (value >= 10) { value /= 10; ++digits; }
    return digits;
}

static int add_length(size_t *length, size_t addition)
{
    if (*length > (size_t)-1 - addition) return 0;
    *length += addition;
    return 1;
}

/* The final three characters of each segment are always the slot, so a
 * preceding decimal field is unambiguous. The first level is absolute; later
 * levels are deltas from the previous step. Omit +1, the common case. '/' is
 * only a step separator, never a unary level count. */
static LksStatus measure_path_text(const LksPath *path, size_t *out_length)
{
    LksDirection direction = lks_path_direction(path);
    size_t depth = lks_path_depth(path), length = 1, previous = 0, index;
    if (direction == LKS_DIRECTION_ZERO) {
        if (depth != 0) return LKS_STATUS_INTERNAL_ERROR;
        *out_length = sizeof(zero_path_text) - 1;
        return LKS_STATUS_OK;
    }
    if ((direction != LKS_DIRECTION_POSITIVE &&
         direction != LKS_DIRECTION_NEGATIVE) || depth == 0)
        return LKS_STATUS_INTERNAL_ERROR;
    for (index = 0; index < depth; ++index) {
        unsigned int slot;
        size_t level, level_delta, decimal_prefix_length = 0;
        if (lks_path_get_slot(path, index, &slot) != LKS_STATUS_OK ||
            slot > LKS_PATH_SLOT_MAX ||
            lks_path_get_level(path, index, &level) != LKS_STATUS_OK ||
            (index != 0 && level <= previous))
            return LKS_STATUS_INTERNAL_ERROR;
        level_delta = index == 0 ? level : level - previous;
        if ((index == 0 && level_delta != 0) ||
            (index != 0 && level_delta > 1))
            decimal_prefix_length = decimal_digits(level_delta);
        if (!add_length(&length, LKS_SLOT_TEXT_WIDTH + (index != 0)) ||
            !add_length(&length, decimal_prefix_length))
            return LKS_STATUS_INTERNAL_ERROR;
        previous = level;
    }
    *out_length = length;
    return LKS_STATUS_OK;
}

size_t lks_path_text_length(const LksPath *path)
{
    size_t length;
    return path != NULL && measure_path_text(path, &length) == LKS_STATUS_OK ?
        length : 0;
}

static size_t write_decimal_level(char *buffer, size_t index, size_t level_value)
{
    size_t digits = decimal_digits(level_value), cursor = index + digits;
    do {
        buffer[--cursor] = (char)('0' + level_value % 10);
        level_value /= 10;
    } while (level_value != 0);
    return index + digits;
}

LksStatus lks_path_format(const LksPath *path, char *buffer, size_t buffer_size)
{
    LksDirection direction;
    size_t required_length, depth, index, output_index = 0, previous_level = 0;
    LksStatus status;
    if (path == NULL || buffer == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    /* Validate and bound the entire no-allocation output before writing. */
    status = measure_path_text(path, &required_length);
    if (status != LKS_STATUS_OK) return status;
    if (required_length == (size_t)-1 || buffer_size < required_length + 1)
        return LKS_STATUS_BUFFER_TOO_SMALL;
    direction = lks_path_direction(path);
    if (direction == LKS_DIRECTION_ZERO) {
        memcpy(buffer, zero_path_text, sizeof(zero_path_text));
        return LKS_STATUS_OK;
    }
    buffer[output_index++] = direction == LKS_DIRECTION_POSITIVE ? '0' : '1';
    depth = lks_path_depth(path);
    for (index = 0; index < depth; ++index) {
        size_t level, level_delta, digit_index;
        unsigned int slot;
        char token[LKS_SLOT_TEXT_WIDTH];
        if (lks_path_get_level(path, index, &level) != LKS_STATUS_OK ||
            lks_path_get_slot(path, index, &slot) != LKS_STATUS_OK ||
            !lks_slot_encode(slot, token))
            return LKS_STATUS_INTERNAL_ERROR;
        if (index != 0) buffer[output_index++] = '/';
        level_delta = index == 0 ? level : level - previous_level;
        if ((index == 0 && level_delta != 0) ||
            (index != 0 && level_delta > 1))
            output_index = write_decimal_level(buffer, output_index, level_delta);
        for (digit_index = 0; digit_index < LKS_SLOT_TEXT_WIDTH; ++digit_index)
            buffer[output_index++] = token[digit_index];
        previous_level = level;
    }
    buffer[output_index] = '\0';
    return output_index == required_length ? LKS_STATUS_OK :
        LKS_STATUS_INTERNAL_ERROR;
}

LksStatus lks_path_parse(const char *text, LksPath **out_path)
{
    LksPath *path = NULL;
    LksDirection direction;
    size_t length, start, previous = 0, depth = 0;
    LksStatus status = LKS_STATUS_INVALID_ARGUMENT;
    if (out_path == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    *out_path = NULL;
    if (text == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    if (strcmp(text, zero_path_text) == 0) {
        path = lks_path_create_zero();
        if (path == NULL) return LKS_STATUS_OUT_OF_MEMORY;
        *out_path = path;
        return LKS_STATUS_OK;
    }
    length = strlen(text);
    if (length < 4 || (text[0] != '0' && text[0] != '1'))
        return LKS_STATUS_INVALID_ARGUMENT;
    direction = text[0] == '0' ? LKS_DIRECTION_POSITIVE : LKS_DIRECTION_NEGATIVE;
    start = 1;
    while (start < length) {
        size_t end = start, prefix_end, value = 0, level;
        unsigned int slot;
        while (end < length && text[end] != '/') ++end;
        if (end - start < LKS_SLOT_TEXT_WIDTH) goto fail;
        prefix_end = end - LKS_SLOT_TEXT_WIDTH;
        if (prefix_end != start && text[start] == '0') goto fail;
        for (size_t i = start; i < prefix_end; ++i) {
            unsigned int digit;
            if (text[i] < '0' || text[i] > '9') goto fail;
            digit = (unsigned int)(text[i] - '0');
            if (value > (SIZE_MAX - digit) / 10) goto fail;
            value = value * 10 + digit;
        }
        if (!lks_slot_decode(text + prefix_end, &slot)) goto fail;
        if (depth == 0) {
            if (prefix_end != start && value == 0) goto fail;
            level = value;
            path = lks_path_create_at_level(direction, slot, level);
            if (path == NULL) { status = LKS_STATUS_OUT_OF_MEMORY; goto fail; }
        } else {
            if (prefix_end == start) value = 1;
            else if (value <= 1) goto fail;
            if (value > SIZE_MAX - previous) goto fail;
            level = previous + value;
            status = lks_path_append_at_level(path, slot, level);
            if (status != LKS_STATUS_OK) goto fail;
        }
        previous = level;
        ++depth;
        status = LKS_STATUS_INVALID_ARGUMENT;
        if (end == length) break;
        start = end + 1;
        if (start == length) goto fail;
    }
    *out_path = path;
    return LKS_STATUS_OK;
fail:
    lks_path_destroy(path);
    return status;
}
/* End production source: src/path_text.c */

/* Begin production source: src/path_order_key.c */
#include <stdint.h>
#include <string.h>
/* bundled include: lks_legacy_internal.h */

/* LK1 payload: direction, zero or more self-delimiting steps, '!'. The
 * constant family/version prefix has no effect on same-version ordering. */
/* Numeric byte values keep the wire format ASCII even on a host whose C
 * execution character set is not ASCII. */
enum { K_END = 0x21, K_ZERO = 0x30, K_ONE = 0x31, K_TWO = 0x32 };
static const char key_prefix[] = {0x4c, 0x4b, 0x31, 0x3a, 0};
static const char hex_digits[] = {
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46
};

static size_t byte_count(size_t value)
{
    size_t count = 1;
    while (value >= 256) { value /= 256; ++count; }
    return count;
}

static int add_size(size_t *total, size_t amount)
{
    if (*total > SIZE_MAX - amount) return 0;
    *total += amount;
    return 1;
}

static LksStatus measure(const LksPath *path, size_t *out_length)
{
    LksDirection direction;
    size_t depth, length = sizeof(key_prefix) - 1 + 2, previous = 0;
    if (path == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    direction = lks_path_direction(path);
    depth = lks_path_depth(path);
    if (direction == LKS_DIRECTION_ZERO) {
        if (depth != 0) return LKS_STATUS_INTERNAL_ERROR;
        *out_length = length;
        return LKS_STATUS_OK;
    }
    if ((direction != LKS_DIRECTION_NEGATIVE &&
         direction != LKS_DIRECTION_POSITIVE) || depth == 0)
        return LKS_STATUS_INTERNAL_ERROR;
    for (size_t i = 0; i < depth; ++i) {
        size_t level, bytes;
        unsigned int slot;
        if (lks_path_get_level(path, i, &level) != LKS_STATUS_OK ||
            lks_path_get_slot(path, i, &slot) != LKS_STATUS_OK ||
            slot > LKS_PATH_SLOT_MAX || (i != 0 && level <= previous))
            return LKS_STATUS_INTERNAL_ERROR;
        bytes = byte_count(level);
        if (bytes > (SIZE_MAX - 5) / 3 || !add_size(&length, 3 * bytes + 5))
            return LKS_STATUS_INTERNAL_ERROR;
        previous = level;
    }
    *out_length = length;
    return LKS_STATUS_OK;
}

size_t lks_path_order_key_length(const LksPath *path)
{
    size_t length;
    return measure(path, &length) == LKS_STATUS_OK ? length : 0;
}

static void write_hex_byte(char *output, unsigned int byte)
{
    output[0] = hex_digits[byte >> 4];
    output[1] = hex_digits[byte & 15u];
}

LksStatus lks_path_order_key_format(const LksPath *path,
    char *buffer, size_t buffer_size)
{
    size_t length, cursor = 0, depth;
    LksDirection direction;
    LksStatus status;
    if (path == NULL || buffer == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    status = measure(path, &length);
    if (status != LKS_STATUS_OK) return status;
    if (length == SIZE_MAX || buffer_size < length + 1)
        return LKS_STATUS_BUFFER_TOO_SMALL;
    memcpy(buffer, key_prefix, sizeof(key_prefix) - 1);
    cursor = sizeof(key_prefix) - 1;
    direction = lks_path_direction(path);
    buffer[cursor++] = direction == LKS_DIRECTION_NEGATIVE ? K_ZERO :
        direction == LKS_DIRECTION_ZERO ? K_ONE : K_TWO;
    depth = lks_path_depth(path);
    for (size_t i = 0; i < depth; ++i) {
        unsigned char bytes[sizeof(size_t)];
        size_t level, count, value;
        unsigned int slot;
        /* MEASURE already checked validity, so these reads cannot fail. */
        (void)lks_path_get_level(path, i, &level);
        (void)lks_path_get_slot(path, i, &slot);
        count = byte_count(level);
        value = level;
        for (size_t j = count; j > 0; --j) {
            bytes[j - 1] = (unsigned char)(value % 256);
            value /= 256;
        }
        for (size_t j = 0; j < count; ++j) buffer[cursor++] = K_ZERO;
        buffer[cursor++] = K_ONE;
        for (size_t j = 0; j < count; ++j) {
            write_hex_byte(buffer + cursor, 255u - bytes[j]);
            cursor += 2;
        }
        if (direction == LKS_DIRECTION_NEGATIVE && i == 0)
            slot = LKS_PATH_SLOT_MAX - slot;
        for (size_t j = 4; j > 0; --j) {
            buffer[cursor + j - 1] = hex_digits[slot & 15u];
            slot >>= 4;
        }
        cursor += 4;
    }
    buffer[cursor++] = K_END;
    buffer[cursor] = '\0';
    return cursor == length ? LKS_STATUS_OK : LKS_STATUS_INTERNAL_ERROR;
}

static int hex_value(char c)
{
    if (c >= 0x30 && c <= 0x39) return c - 0x30;
    if (c >= 0x41 && c <= 0x46) return c - 0x41 + 10;
    return -1;
}

LksStatus lks_path_order_key_parse(const char *key, LksPath **out_path)
{
    LksPath *path = NULL;
    LksDirection direction;
    size_t length, cursor, previous = 0, depth = 0;
    LksStatus status = LKS_STATUS_INVALID_ARGUMENT;
    if (out_path == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    *out_path = NULL;
    if (key == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    length = strlen(key);
    if (length < sizeof(key_prefix) - 1 + 2 ||
        memcmp(key, key_prefix, sizeof(key_prefix) - 1) != 0 ||
        key[length - 1] != K_END) return LKS_STATUS_INVALID_ARGUMENT;
    cursor = sizeof(key_prefix) - 1;
    if (key[cursor] == K_ONE) {
        if (length != sizeof(key_prefix) - 1 + 2) return status;
        path = lks_path_create_zero();
        if (path == NULL) return LKS_STATUS_OUT_OF_MEMORY;
        *out_path = path;
        return LKS_STATUS_OK;
    }
    if (key[cursor] != K_ZERO && key[cursor] != K_TWO) return status;
    direction = key[cursor++] == K_ZERO ? LKS_DIRECTION_NEGATIVE :
        LKS_DIRECTION_POSITIVE;
    if (key[cursor] == K_END) return status;
    while (cursor < length - 1) {
        size_t count = 0, level = 0;
        unsigned int slot = 0;
        while (cursor < length - 1 && key[cursor] == K_ZERO) {
            if (count == sizeof(size_t)) goto fail;
            ++count; ++cursor;
        }
        if (count == 0 || cursor >= length - 1 || key[cursor++] != K_ONE ||
            count > (length - 1 - cursor) / 2 ||
            length - 1 - cursor - 2 * count < 4) goto fail;
        for (size_t i = 0; i < count; ++i) {
            int high = hex_value(key[cursor++]);
            int low = hex_value(key[cursor++]);
            unsigned int byte;
            if (high < 0 || low < 0) goto fail;
            byte = 255u - (unsigned int)(high * 16 + low);
            if (i == 0 && count > 1 && byte == 0) goto fail;
            if (level > (SIZE_MAX - byte) / 256) goto fail;
            level = level * 256 + byte;
        }
        for (size_t i = 0; i < 4; ++i) {
            int digit = hex_value(key[cursor++]);
            if (digit < 0) goto fail;
            slot = slot * 16u + (unsigned int)digit;
        }
        if (direction == LKS_DIRECTION_NEGATIVE && depth == 0)
            slot = LKS_PATH_SLOT_MAX - slot;
        if (depth == 0) {
            path = lks_path_create_at_level(direction, slot, level);
            if (path == NULL) { status = LKS_STATUS_OUT_OF_MEMORY; goto fail; }
        } else {
            if (level <= previous) goto fail;
            status = lks_path_append_at_level(path, slot, level);
            if (status != LKS_STATUS_OK) goto fail;
        }
        previous = level;
        ++depth;
        status = LKS_STATUS_INVALID_ARGUMENT;
    }
    if (cursor != length - 1) goto fail;
    *out_path = path;
    return LKS_STATUS_OK;
fail:
    lks_path_destroy(path);
    return status;
}
/* End production source: src/path_order_key.c */

/* Begin production source: src/slot_codec.c */
/* bundled include: lks_legacy_internal.h */
/* bundled include: lks_slot_codec_internal.h */

/* ASCII-ordered alphanumerics omit 0/O/o and 1/I/i/L/l to make handwritten
 * Paths easier to inspect. No punctuation can collide with the '/' separator
 * or require escaping in common logs, URLs, and shell/config contexts. The
 * fixed three-character width covers all 65536 slots because 54^3 > 65536. */
static const char slot_alphabet[] =
    "23456789ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz";

_Static_assert(sizeof(slot_alphabet) == LKS_SLOT_TEXT_RADIX + 1,
    "slot alphabet must contain exactly 54 characters");
_Static_assert(LKS_SLOT_TEXT_WIDTH == 3,
    "the Preview.3 slot grammar uses exactly three characters");
_Static_assert(LKS_SLOT_TEXT_RADIX * LKS_SLOT_TEXT_RADIX * LKS_SLOT_TEXT_RADIX >
    LKS_PATH_SLOT_MAX, "three radix-54 digits must cover every slot");

int lks_slot_encode(unsigned int slot, char output[LKS_SLOT_TEXT_WIDTH])
{
    int digit_index;
    unsigned int remaining_slot = slot;
    if (output == NULL || slot > LKS_PATH_SLOT_MAX) return 0;
    for (digit_index = LKS_SLOT_TEXT_WIDTH - 1; digit_index >= 0; --digit_index) {
        output[digit_index] = slot_alphabet[remaining_slot % LKS_SLOT_TEXT_RADIX];
        remaining_slot /= LKS_SLOT_TEXT_RADIX;
    }
    return 1;
}

int lks_slot_decode(const char input[LKS_SLOT_TEXT_WIDTH], unsigned int *out_slot)
{
    unsigned int value = 0;
    int i;
    if (input == NULL || out_slot == NULL) return 0;
    for (i = 0; i < LKS_SLOT_TEXT_WIDTH; ++i) {
        unsigned int rank;
        for (rank = 0; rank < LKS_SLOT_TEXT_RADIX; ++rank)
            if (input[i] == slot_alphabet[rank]) break;
        if (rank == LKS_SLOT_TEXT_RADIX) return 0;
        value = value * LKS_SLOT_TEXT_RADIX + rank;
    }
    if (value > LKS_PATH_SLOT_MAX) return 0;
    *out_slot = value;
    return 1;
}
/* End production source: src/slot_codec.c */

/* Begin production source: src/path_compare.c */
/* bundled include: lks_legacy_internal.h */

static int direction_rank(LksDirection direction)
{
    switch (direction) {
    case LKS_DIRECTION_NEGATIVE:
        return 0;
    case LKS_DIRECTION_ZERO:
        return 1;
    case LKS_DIRECTION_POSITIVE:
        return 2;
    default:
        return -1;
    }
}

static int path_is_consistent(
    const LksPath *path,
    LksDirection direction,
    size_t depth
)
{
    size_t index;
    size_t level;
    size_t previous_level;
    unsigned int slot;

    if (direction == LKS_DIRECTION_ZERO) {
        return depth == 0;
    }
    if ((direction != LKS_DIRECTION_POSITIVE &&
         direction != LKS_DIRECTION_NEGATIVE) || depth == 0) {
        return 0;
    }

    previous_level = 0;
    for (index = 0; index < depth; ++index) {
        if (lks_path_get_slot(path, index, &slot) != LKS_STATUS_OK ||
            slot > LKS_PATH_SLOT_MAX ||
            lks_path_get_level(path, index, &level) != LKS_STATUS_OK) {
            return 0;
        }
        if (index > 0 && level <= previous_level) {
            return 0;
        }
        previous_level = level;
    }
    return 1;
}

LksStatus lks_path_compare(
    const LksPath *left,
    const LksPath *right,
    int *out_result
)
{
    LksDirection left_direction;
    LksDirection right_direction;
    size_t left_depth;
    size_t right_depth;
    size_t common_depth;
    size_t index;
    size_t left_level;
    size_t right_level;
    unsigned int left_slot;
    unsigned int right_slot;
    int left_rank;
    int right_rank;
    int result;

    if (left == NULL || right == NULL || out_result == NULL) {
        return LKS_STATUS_INVALID_ARGUMENT;
    }

    left_direction = lks_path_direction(left);
    right_direction = lks_path_direction(right);
    left_depth = lks_path_depth(left);
    right_depth = lks_path_depth(right);

    left_rank = direction_rank(left_direction);
    right_rank = direction_rank(right_direction);
    if (left_rank < 0 || right_rank < 0 ||
        !path_is_consistent(left, left_direction, left_depth) ||
        !path_is_consistent(right, right_direction, right_depth)) {
        return LKS_STATUS_INTERNAL_ERROR;
    }

    if (left_direction != right_direction) {
        *out_result = (left_rank < right_rank) ? -1 : 1;
        return LKS_STATUS_OK;
    }

    if (left_direction == LKS_DIRECTION_ZERO) {
        *out_result = 0;
        return LKS_STATUS_OK;
    }

    common_depth = (left_depth < right_depth) ? left_depth : right_depth;
    for (index = 0; index < common_depth; ++index) {
        if (lks_path_get_slot(left, index, &left_slot) != LKS_STATUS_OK ||
            lks_path_get_slot(right, index, &right_slot) != LKS_STATUS_OK ||
            lks_path_get_level(left, index, &left_level) != LKS_STATUS_OK ||
            lks_path_get_level(right, index, &right_level) != LKS_STATUS_OK) {
            return LKS_STATUS_INTERNAL_ERROR;
        }

        if (left_level != right_level) {
            *out_result = (left_level > right_level) ? -1 : 1;
            return LKS_STATUS_OK;
        }

        if (left_slot != right_slot) {
            if (left_direction == LKS_DIRECTION_NEGATIVE && index == 0) {
                result = (left_slot > right_slot) ? -1 : 1;
            } else {
                result = (left_slot < right_slot) ? -1 : 1;
            }
            *out_result = result;
            return LKS_STATUS_OK;
        }
    }

    if (left_depth < right_depth) {
        *out_result = -1;
    } else if (left_depth > right_depth) {
        *out_result = 1;
    } else {
        *out_result = 0;
    }
    return LKS_STATUS_OK;
}
/* End production source: src/path_compare.c */

/* Begin production source: src/order.c */
/* bundled include: layerkeysort.h */
/* bundled include: lks_order_internal.h */
/* bundled include: lks_alloc_internal.h */
#include <assert.h>
#include <string.h>

_Static_assert(LKS_ORDER_BLOCK_CAPACITY >= 8u &&
    LKS_ORDER_BLOCK_CAPACITY % 2u == 0u, "even half-full block policy required");

/* No V3 Path/index coupling: order is the implicit in-order block sequence. */
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
#define V4_COUNT(order, field) (++(order)->work.field)
static void v4_mark_index(LksOrder *order, const LksOrderBlock *block)
{
    size_t i;
    if (!block) return;
    for (i = 0; i < order->work.index_blocks; ++i)
        if (order->work.tracked[i] == block) return;
    if (i == LKS_ORDER_DIAG_TRACK_LIMIT) {
        order->work.tracking_overflow = 1;
        return;
    }
    order->work.tracked[i] = block;
    ++order->work.index_blocks;
}
static void v4_begin(LksOrder *order)
{ memset(&order->work, 0, sizeof(order->work)); }
#else
#define V4_COUNT(order, field) ((void)(order))
#define v4_mark_index(order, block) ((void)(order), (void)(block))
#define v4_begin(order) ((void)(order))
#endif

static int v4_height(const LksOrderBlock *block)
{ return block ? block->height : 0; }
static size_t v4_subtree(const LksOrderBlock *block)
{ return block ? block->subtree_blocks : 0; }
static void v4_refresh(LksOrder *order, LksOrderBlock *block)
{
    int left = v4_height(block->left), right = v4_height(block->right);
    v4_mark_index(order, block);
    block->height = 1 + (left > right ? left : right);
    block->subtree_blocks = 1 + v4_subtree(block->left) + v4_subtree(block->right);
}
static void v4_replace(LksOrder *order, LksOrderBlock *old,
    LksOrderBlock *replacement)
{
    LksOrderBlock *parent = old->parent;
    v4_mark_index(order, parent);
    v4_mark_index(order, replacement);
    if (!parent) order->root = replacement;
    else if (parent->left == old) parent->left = replacement;
    else parent->right = replacement;
    if (replacement) replacement->parent = parent;
}
static LksOrderBlock *v4_rotate_left(LksOrder *order, LksOrderBlock *block)
{
    LksOrderBlock *pivot = block->right;
    v4_replace(order, block, pivot);
    block->right = pivot->left;
    v4_mark_index(order, block->right);
    if (block->right) block->right->parent = block;
    pivot->left = block;
    block->parent = pivot;
    v4_refresh(order, block);
    v4_refresh(order, pivot);
    V4_COUNT(order, rotations); V4_COUNT(order, left_rotations);
    return pivot;
}
static LksOrderBlock *v4_rotate_right(LksOrder *order, LksOrderBlock *block)
{
    LksOrderBlock *pivot = block->left;
    v4_replace(order, block, pivot);
    block->left = pivot->right;
    v4_mark_index(order, block->left);
    if (block->left) block->left->parent = block;
    pivot->right = block;
    block->parent = pivot;
    v4_refresh(order, block);
    v4_refresh(order, pivot);
    V4_COUNT(order, rotations); V4_COUNT(order, right_rotations);
    return pivot;
}
static void v4_balance(LksOrder *order, LksOrderBlock *block)
{
    while (block) {
        int balance;
        v4_refresh(order, block);
        balance = v4_height(block->left) - v4_height(block->right);
        if (balance > 1) {
            if (v4_height(block->left->left) < v4_height(block->left->right)) {
                v4_rotate_left(order, block->left);
                V4_COUNT(order, left_right_rotations);
            }
            block = v4_rotate_right(order, block);
        } else if (balance < -1) {
            if (v4_height(block->right->right) < v4_height(block->right->left)) {
                v4_rotate_right(order, block->right);
                V4_COUNT(order, right_left_rotations);
            }
            block = v4_rotate_left(order, block);
        }
        block = block->parent;
    }
}
static LksOrderBlock *v4_minimum(LksOrderBlock *block)
{
    while (block->left) block = block->left;
    return block;
}
static LksOrderBlock *v4_new_block(LksOrder *owner)
{
    LksOrderBlock *block = (LksOrderBlock *)lks_alloc(sizeof(*block));
    if (block) {
        memset(block, 0, sizeof(*block));
        block->owner = owner; block->height = 1; block->subtree_blocks = 1;
    }
    return block;
}
/* Bounded ordered-range redistribution for block precedence.
 * Zero denotes a block that still uses AVL precedence. */
static void v4_tag_attach(LksOrder *order, LksOrderBlock *block)
{
    LksOrderBlock *left = block, *right = block;
    size_t width = 1;
    for (;;) {
        uint64_t lower = left->previous ? left->previous->tag : 0;
        uint64_t upper = right->next ? right->next->tag : UINT64_MAX;
        int bounded = (!left->previous || lower) && upper;
        if (bounded && upper > lower) {
            uint64_t stride = (upper - lower) / (width + 1);
            /* Spread a repaired range to leave room for further insertions. */
            if (stride >= (width == 1 ? 1 : width)) {
                if (width == 1 && !right->next && stride > UINT64_C(1099511627776))
                    stride = UINT64_C(1099511627776);
                uint64_t label = lower;
                for (LksOrderBlock *p = left;; p = p->next) {
                    label += stride;
                    p->tag = label;
                    if (p == right) break;
                }
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
                order->tag_writes += width;
                if (width > 1) ++order->tag_repairs;
                if (width > order->max_tag_writes) order->max_tag_writes = width;
#else
                (void)order;
#endif
                return;
            }
        }
        if (width == 64 || (!left->previous && !right->next)) {
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
            ++order->tag_fallbacks;
#endif
            return;
        }
        if (left->previous && (!right->next || !lower || width % 2 == 0)) left = left->previous;
        else right = right->next;
        ++width;
    }
}

/* Called only with a prepared block; an implicit insertion has no search key. */
static void v4_link_after(LksOrder *order, LksOrderBlock *anchor,
    LksOrderBlock *block)
{
    LksOrderBlock *parent;
    if (!anchor) {
        assert(!order->root);
        order->root = order->first = order->last = block;
        parent = NULL;
    } else {
        block->previous = anchor; block->next = anchor->next;
        v4_mark_index(order, anchor); v4_mark_index(order, block->next);
        if (block->next) block->next->previous = block;
        else order->last = block;
        anchor->next = block;
        if (!anchor->right) { parent = anchor; parent->right = block; }
        else { parent = v4_minimum(anchor->right); parent->left = block; }
        block->parent = parent;
        v4_mark_index(order, parent);
    }
    v4_mark_index(order, block);
    ++order->blocks;
    v4_tag_attach(order, block);
    v4_balance(order, parent);
}
/* Physically transplant the successor. Copying its array would break stable
 * record-to-block locations, so block identity and threaded order are retained. */
static void v4_detach(LksOrder *order, LksOrderBlock *block)
{
    LksOrderBlock *start;
    v4_mark_index(order, block);
    v4_mark_index(order, block->previous); v4_mark_index(order, block->next);
    if (block->previous) block->previous->next = block->next;
    else order->first = block->next;
    if (block->next) block->next->previous = block->previous;
    else order->last = block->previous;
    if (!block->left || !block->right) {
        start = block->parent;
        v4_replace(order, block, block->left ? block->left : block->right);
        if (!start) start = order->root;
    } else {
        LksOrderBlock *successor = v4_minimum(block->right);
        V4_COUNT(order, two_child_detaches);
        if (successor->parent == block) {
            v4_replace(order, block, successor);
            successor->left = block->left;
            v4_mark_index(order, successor->left);
            successor->left->parent = successor;
            start = successor;
        } else {
            start = successor->parent;
            v4_replace(order, successor, successor->right);
            v4_replace(order, block, successor);
            successor->left = block->left; successor->right = block->right;
            v4_mark_index(order, successor->left);
            v4_mark_index(order, successor->right);
            successor->left->parent = successor;
            successor->right->parent = successor;
        }
    }
    --order->blocks;
    v4_balance(order, start);
}
static void v4_locations(LksOrder *order, LksOrderBlock *block)
{
    size_t i;
    assert(block->count <= LKS_ORDER_BLOCK_CAPACITY);
    V4_COUNT(order, local_blocks);
    for (i = 0; i < block->count; ++i) {
        block->records[i]->block = block;
        block->records[i]->local = i;
        V4_COUNT(order, records_reassigned);
    }
    for (; i <= LKS_ORDER_BLOCK_CAPACITY; ++i) block->records[i] = NULL;
}
/* Ordinary shifts preserve block membership. Structural repair still uses
 * v4_locations because it can migrate residents between blocks. */
static void v4_shifted_locations(LksOrder *order, LksOrderBlock *block, size_t first)
{
    V4_COUNT(order, local_blocks);
    for (size_t i = first; i < block->count; ++i) {
        block->records[i]->local = i;
        V4_COUNT(order, records_reassigned);
    }
}
LksOrder *lks_order_create(void)
{
    LksOrder *order = (LksOrder *)lks_alloc(sizeof(*order));
    if (order) memset(order, 0, sizeof(*order));
    return order;
}
void lks_order_destroy(LksOrder *order)
{
    LksOrderBlock *block;
    if (!order || order->callback_active) return;
    block = order->first;
    while (block) {
        LksOrderBlock *next = block->next;
        size_t i;
        for (i = 0; i < block->count; ++i) lks_free(block->records[i]);
        lks_free(block); block = next;
    }
    lks_source_marker_release(order->source_marker);
    lks_free(order);
}
size_t lks_order_size(const LksOrder *order)
{ return order && !order->callback_active ? order->count : 0; }

/* Shared allocation-free placement for new records and existing moved records.
 * Caller prepared SPARE iff BLOCK is empty/full; no record allocation here. */
static void v4_place(LksOrder *order, LksOrderBlock *block, size_t at,
    LksOrderHandle *record, LksOrderBlock *spare)
{
    size_t i;
    if (!block) { block = spare; v4_link_after(order, NULL, block); spare = NULL; }
    assert(at <= block->count);
    for (i = block->count; i > at; --i) block->records[i] = block->records[i-1];
    block->records[at] = record; ++block->count;
    if (spare) {
        size_t left = block->count / 2;
        spare->count = block->count - left;
        memcpy(spare->records, block->records + left,
            spare->count * sizeof(*spare->records));
        block->count = left;
        assert(block->count >= LKS_ORDER_BLOCK_MIN && spare->count >= LKS_ORDER_BLOCK_MIN);
        v4_locations(order, block); v4_locations(order, spare);
        v4_link_after(order, block, spare);
        V4_COUNT(order, splits);
    } else {
        record->block = block;
        v4_shifted_locations(order, block, at);
    }
}

static LksStatus v4_insert(LksOrder *order, LksOrderBlock *block, size_t at,
    void *item, const LksOrderHandle **out_handle)
{
    LksOrderHandle *record;
    LksOrderBlock *spare = NULL;
    if (out_handle) *out_handle = NULL;
    if (!order || !item || !out_handle) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->callback_active) return LKS_STATUS_REENTRANT;
    v4_begin(order);
    if (order->count == SIZE_MAX || (uintmax_t)order->count >= UINT64_MAX ||
        order->revision == UINT64_MAX) return LKS_STATUS_CAPACITY_LIMIT;
    record = (LksOrderHandle *)lks_alloc(sizeof(*record));
    if (!record) return LKS_STATUS_OUT_OF_MEMORY;
    if (!block || block->count == LKS_ORDER_BLOCK_CAPACITY) {
        spare = v4_new_block(order);
        if (!spare) { lks_free(record); return LKS_STATUS_OUT_OF_MEMORY; }
    }
    record->item = item;
    /* Preparation has finished. No recoverable work/callback/allocation follows. */
    v4_place(order, block, at, record, spare);
    ++order->count; ++order->revision;
    *out_handle = record;
    return LKS_STATUS_OK;
}
LksStatus lks_order_insert_front(LksOrder *order, void *item,
    const LksOrderHandle **out_handle)
{ return v4_insert(order, order ? order->first : NULL, 0, item, out_handle); }
LksStatus lks_order_insert_back(LksOrder *order, void *item,
    const LksOrderHandle **out_handle)
{
    LksOrderBlock *last = order ? order->last : NULL;
    return v4_insert(order, last, last ? last->count : 0, item, out_handle);
}
static LksStatus v4_insert_relative(LksOrder *order, const LksOrderHandle *anchor,
    void *item, const LksOrderHandle **out_handle, int after)
{
    if (out_handle) *out_handle = NULL;
    if (!order || !anchor || anchor->block->owner != order) return LKS_STATUS_INVALID_ARGUMENT;
    return v4_insert(order, anchor->block, anchor->local + (size_t)after, item, out_handle);
}
LksStatus lks_order_insert_before(LksOrder *order, const LksOrderHandle *anchor,
    void *item, const LksOrderHandle **out_handle)
{ return v4_insert_relative(order, anchor, item, out_handle, 0); }
LksStatus lks_order_insert_after(LksOrder *order, const LksOrderHandle *anchor,
    void *item, const LksOrderHandle **out_handle)
{ return v4_insert_relative(order, anchor, item, out_handle, 1); }

/* Only the just-deleted source can underflow. A pair total <= B merges; otherwise
 * balanced halves each contain >= B/2. No second repair/maintenance queue exists. */
static void v4_repair(LksOrder *order, LksOrderBlock *block)
{
    LksOrderBlock *left = block->next ? block : block->previous;
    LksOrderBlock *right = left->next;
    LksOrderHandle *records[2u * LKS_ORDER_BLOCK_CAPACITY];
    size_t total = left->count + right->count;
    assert(block->count == LKS_ORDER_BLOCK_MIN - 1u &&
        total >= 2u * LKS_ORDER_BLOCK_MIN - 1u &&
        total <= LKS_ORDER_BLOCK_CAPACITY + LKS_ORDER_BLOCK_MIN - 1u);
    memcpy(records, left->records, left->count * sizeof(*records));
    memcpy(records + left->count, right->records, right->count * sizeof(*records));
    if (total <= LKS_ORDER_BLOCK_CAPACITY) {
        memcpy(left->records, records, total * sizeof(*records));
        left->count = total;
        v4_locations(order, left);
        /* Count both participating arrays even though the right is retired. */
        V4_COUNT(order, local_blocks); V4_COUNT(order, merges);
        v4_detach(order, right);
        lks_free(right);
    } else {
        left->count = total / 2; right->count = total - left->count;
        memcpy(left->records, records, left->count * sizeof(*records));
        memcpy(right->records, records + left->count, right->count * sizeof(*records));
        v4_locations(order, left); v4_locations(order, right);
        V4_COUNT(order, redistributions);
    }
}
LksStatus lks_order_remove(LksOrder *order, const LksOrderHandle *handle,
    void **out_item)
{
    LksOrderBlock *block;
    LksOrderHandle *record;
    size_t i;
    void *item;
    if (out_item) *out_item = NULL;
    if (!order || !handle || handle->block->owner != order) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->callback_active) return LKS_STATUS_REENTRANT;
    v4_begin(order);
    if (order->revision == UINT64_MAX) return LKS_STATUS_CAPACITY_LIMIT;
    block = handle->block; record = block->records[handle->local]; item = record->item;
    for (i = handle->local; i + 1 < block->count; ++i)
        block->records[i] = block->records[i+1];
    --block->count; --order->count;
    if (!block->count && order->blocks == 1) {
        V4_COUNT(order, local_blocks);
        v4_detach(order, block); lks_free(block);
    } else if (order->blocks > 1 && block->count < LKS_ORDER_BLOCK_MIN)
        v4_repair(order, block);
    else {
        block->records[block->count] = NULL;
        v4_shifted_locations(order, block, record->local);
    }
    ++order->revision;
    lks_free(record);
    if (out_item) *out_item = item;
    return LKS_STATUS_OK;
}
const LksOrderHandle *lks_order_first(const LksOrder *order)
{ return order && !order->callback_active && order->first ? order->first->records[0] : NULL; }
const LksOrderHandle *lks_order_last(const LksOrder *order)
{
    return order && !order->callback_active && order->last ? order->last->records[order->last->count-1] : NULL;
}
const LksOrderHandle *lks_order_next(const LksOrderHandle *handle)
{
    if (!handle || handle->block->owner->callback_active) return NULL;
    if (handle->local + 1 < handle->block->count)
        return handle->block->records[handle->local+1];
    return handle->block->next ? handle->block->next->records[0] : NULL;
}
const LksOrderHandle *lks_order_previous(const LksOrderHandle *handle)
{
    const LksOrderBlock *previous;
    if (!handle || handle->block->owner->callback_active) return NULL;
    if (handle->local) return handle->block->records[handle->local-1];
    previous = handle->block->previous;
    return previous ? previous->records[previous->count-1] : NULL;
}
void *lks_order_item(const LksOrderHandle *handle)
{ return handle && !handle->block->owner->callback_active ? handle->item : NULL; }
LksStatus lks_order_compare(const LksOrder *order, const LksOrderHandle *a,
                            const LksOrderHandle *b, int *out)
{
    if (out) *out = 0;
    if (!order || !a || !b || !out || a->block->owner != order || b->block->owner != order)
        return LKS_STATUS_INVALID_ARGUMENT;
    if (order->callback_active) return LKS_STATUS_REENTRANT;
    const LksOrderBlock *left = a->block, *right = b->block;
    if (left == right) {
        *out = (a->local > b->local) - (a->local < b->local);
        return LKS_STATUS_OK;
    }
    if (left->tag && right->tag) {
        *out = left->tag < right->tag ? -1 : 1;
        return LKS_STATUS_OK;
    }
    /* Height strictly increases along each parent edge. Advance the lower
     * block until the walks meet as siblings or one reaches the other.
     * Relative precedence then follows from the first divergent child. */
    while (left->parent != right->parent) {
        if (left->height < right->height) {
            if (left->parent == right) {
                *out = right->left == left ? -1 : 1;
                return LKS_STATUS_OK;
            }
            left = left->parent;
        } else {
            if (right->parent == left) {
                *out = left->right == right ? -1 : 1;
                return LKS_STATUS_OK;
            }
            right = right->parent;
        }
    }
    *out = left->parent->left == left ? -1 : 1;
    return LKS_STATUS_OK;
}

static LksStatus v4_move(LksOrder *order, const LksOrderHandle *handle,
    const LksOrderHandle *anchor, int after)
{
    LksOrderBlock *source, *destination, *spare = NULL;
    LksOrderHandle *record;
    size_t from, to, i;
    if (!order || !handle || !anchor || handle->block->owner != order || anchor->block->owner != order)
        return LKS_STATUS_INVALID_ARGUMENT;
    if (order->callback_active) return LKS_STATUS_REENTRANT;
    v4_begin(order);
    if (handle == anchor || (after ? lks_order_next(anchor) == handle : lks_order_next(handle) == anchor)) {
        V4_COUNT(order, noop_moves);
        return LKS_STATUS_OK;
    }
    if (order->revision == UINT64_MAX) return LKS_STATUS_CAPACITY_LIMIT;
    source = handle->block; destination = anchor->block;
    from = handle->local; record = source->records[from];
    if (source == destination) {
        to = anchor->local + (size_t)after;
        if (from < to) --to;
        if (from < to) {
            for (i = from; i < to; ++i) source->records[i] = source->records[i+1];
        } else {
            for (i = from; i > to; --i) source->records[i] = source->records[i-1];
        }
        source->records[to] = record;
        V4_COUNT(order, local_blocks);
        for (i = from < to ? from : to; i <= (from > to ? from : to); ++i) {
            source->records[i]->local = i;
            V4_COUNT(order, records_reassigned);
        }
    } else {
        /* The only fallible work precedes unlinking. Source repair deliberately
         * follows destination placement, using its final neighboring blocks. */
        if (destination->count == LKS_ORDER_BLOCK_CAPACITY) {
            spare = v4_new_block(order);
            if (!spare) return LKS_STATUS_OUT_OF_MEMORY;
        }
        for (i = from; i + 1 < source->count; ++i) source->records[i] = source->records[i+1];
        --source->count;
        source->records[source->count] = NULL;
        to = anchor->local + (size_t)after;
        v4_place(order, anchor->block, to, record, spare);
        if (source->count < LKS_ORDER_BLOCK_MIN) v4_repair(order, source);
        else v4_shifted_locations(order, source, from);
        V4_COUNT(order, cross_block_moves);
    }
    ++order->revision;
    return LKS_STATUS_OK;
}
LksStatus lks_order_move_front(LksOrder *order, const LksOrderHandle *handle)
{
    if (order && order->callback_active) return LKS_STATUS_REENTRANT;
    return v4_move(order, handle, lks_order_first(order), 0);
}
LksStatus lks_order_move_back(LksOrder *order, const LksOrderHandle *handle)
{
    if (order && order->callback_active) return LKS_STATUS_REENTRANT;
    return v4_move(order, handle, lks_order_last(order), 1);
}
LksStatus lks_order_move_before(LksOrder *order, const LksOrderHandle *handle,
    const LksOrderHandle *anchor)
{ return v4_move(order, handle, anchor, 0); }
LksStatus lks_order_move_after(LksOrder *order, const LksOrderHandle *handle,
    const LksOrderHandle *anchor)
{ return v4_move(order, handle, anchor, 1); }

LksStatus lks_order_cursor_create(const LksOrder *order, int reverse,
    LksOrderCursor **out_cursor)
{
    LksOrderCursor *cursor;
    if (out_cursor) *out_cursor = NULL;
    if (!order || !out_cursor || (reverse != 0 && reverse != 1)) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->callback_active) return LKS_STATUS_REENTRANT;
    cursor = (LksOrderCursor *)lks_alloc(sizeof(*cursor));
    if (!cursor) return LKS_STATUS_OUT_OF_MEMORY;
    cursor->owner = order; cursor->revision = order->revision; cursor->reverse = reverse;
    cursor->next = reverse ? lks_order_last(order) : lks_order_first(order);
    *out_cursor = cursor;
    return LKS_STATUS_OK;
}
LksStatus lks_order_cursor_next(LksOrderCursor *cursor, const LksOrderHandle **out_handle)
{
    const LksOrderHandle *next;
    if (out_handle) *out_handle = NULL;
    if (!cursor || !out_handle) return LKS_STATUS_INVALID_ARGUMENT;
    if (cursor->owner->callback_active) return LKS_STATUS_REENTRANT;
    /* Check before even inspecting a cached handle that removal may have freed. */
    if (cursor->revision != cursor->owner->revision) return LKS_STATUS_INVALIDATED;
    next = cursor->next;
    if (next) cursor->next = cursor->reverse ? lks_order_previous(next) : lks_order_next(next);
    *out_handle = next;
    return LKS_STATUS_OK;
}
void lks_order_cursor_destroy(LksOrderCursor *cursor)
{ lks_free(cursor); }

#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
typedef struct V4Check {
    const LksOrder *order;
    const LksOrderBlock *previous;
    size_t budget, residents, blocks;
    uint64_t last_nonzero_tag;
} V4Check;
static int v4_check_node(V4Check *check, const LksOrderBlock *block,
    const LksOrderBlock *parent, size_t depth, int *out_height, size_t *out_blocks)
{
    int lh, rh;
    size_t lb, rb, i;
    if (!block) { *out_height = 0; *out_blocks = 0; return 1; }
    if (!check->budget || depth > 2u * sizeof(size_t) * CHAR_BIT ||
        block->parent != parent || block->owner != check->order) return 0;
    --check->budget;
    if (!v4_check_node(check, block->left, block, depth+1, &lh, &lb)) return 0;
    if (!block->count || block->count > LKS_ORDER_BLOCK_CAPACITY ||
        (check->order->blocks > 1 && block->count < LKS_ORDER_BLOCK_MIN) ||
        block->previous != check->previous ||
        (check->previous ? check->previous->next != block : check->order->first != block))
        return 0;
    /* In-order traversal also follows the verified threaded list. Zero tags
     * use AVL precedence and leave the last assigned label in effect. */
    if (block->tag) {
        if (block->tag <= check->last_nonzero_tag) return 0;
        check->last_nonzero_tag = block->tag;
    }
    for (i = 0; i < block->count; ++i) {
        const LksOrderHandle *record = block->records[i];
        /* A duplicated record cannot simultaneously match two locations. */
        if (!record || !record->item || record->block != block || record->local != i)
            return 0;
    }
    for (; i <= LKS_ORDER_BLOCK_CAPACITY; ++i) if (block->records[i]) return 0;
    if (check->residents > SIZE_MAX - block->count) return 0;
    check->residents += block->count; ++check->blocks; check->previous = block;
    if (!v4_check_node(check, block->right, block, depth+1, &rh, &rb) ||
        lh-rh > 1 || rh-lh > 1 || lb > SIZE_MAX-1 || rb > SIZE_MAX-1-lb) return 0;
    *out_height = 1 + (lh > rh ? lh : rh); *out_blocks = 1 + lb + rb;
    return block->height == *out_height && block->subtree_blocks == *out_blocks;
}
int lks_order_internal_valid(const LksOrder *order)
{
    V4Check check;
    int height;
    size_t blocks, count = 0;
    const LksOrderHandle *handle, *previous = NULL;
    if (!order) return 0;
    check.order = order; check.previous = NULL; check.budget = order->blocks;
    check.residents = check.blocks = 0;
    check.last_nonzero_tag = 0;
    if (!v4_check_node(&check, order->root, NULL, 0, &height, &blocks) ||
        check.budget || blocks != order->blocks || check.blocks != order->blocks ||
        check.residents != order->count || check.previous != order->last ||
        (order->last && order->last->next) ||
        (!order->count && (order->root || order->first || order->last))) return 0;
    for (handle = lks_order_first(order); handle; handle = lks_order_next(handle)) {
        if (count >= order->count || lks_order_previous(handle) != previous) return 0;
        previous = handle; ++count;
    }
    if (count != order->count || previous != lks_order_last(order)) return 0;
    previous = NULL; count = 0;
    for (handle = lks_order_last(order); handle; handle = lks_order_previous(handle)) {
        if (count >= order->count || lks_order_next(handle) != previous) return 0;
        previous = handle; ++count;
    }
    return count == order->count && previous == lks_order_first(order);
}
#endif
/* End production source: src/order.c */

/* Begin production source: src/managed_order.c */
/* bundled include: layerkeysort.h */
/* bundled include: lks_order_internal.h */
/* bundled include: lks_alloc_internal.h */

/* Composition only: no second index, resident wrapper or mutable core escape. */
LksManagedOrder *lks_managed_order_create(const LksComparator *comparator)
{
    LksManagedOrder *order;
    if (!comparator || !comparator->compare) return NULL;
    order = (LksManagedOrder *)lks_alloc(sizeof(*order));
    if (!order) return NULL;
    order->core = lks_order_create();
    if (!order->core) { lks_free(order); return NULL; }
    order->comparator = *comparator; order->active = 0;
    return order;
}
void lks_managed_order_destroy(LksManagedOrder *order)
{
    if (!order || order->active) return;
    lks_order_destroy(order->core); lks_free(order);
}
size_t lks_managed_order_size(const LksManagedOrder *order)
{ return order && !order->active ? lks_order_size(order->core) : 0; }

static int v4_managed_compare_item(LksManagedOrder *order, const void *item,
    const void *query)
{
    int result;
    /* Reentry into this facade/core is rejected even for reads. Other independent
     * containers are allowed. Caller callbacks must return normally (no longjmp). */
    order->core->callback_active = 1;
    result = order->comparator.compare(item, query, order->comparator.context);
    order->core->callback_active = 0;
    return result;
}

/* Find the first block whose maximum exceeds query (upper) or is >= query
 * (lower), then binary-search only that block. No successor/equal-run scan. */
static const LksOrderHandle *v4_managed_bound(LksManagedOrder *order,
    const void *query, int upper)
{
    LksOrderBlock *node = order->core->root, *candidate = NULL;
    size_t low, high;
    while (node) {
        int c = v4_managed_compare_item(order, node->records[node->count-1]->item, query);
        if (c > 0 || (!upper && c == 0)) { candidate = node; node = node->left; }
        else node = node->right;
    }
    if (!candidate) return NULL;
    low = 0; high = candidate->count;
    while (low < high) {
        size_t middle = low + (high-low)/2;
        int c = v4_managed_compare_item(order, candidate->records[middle]->item, query);
        if (c > 0 || (!upper && c == 0)) high = middle;
        else low = middle + 1;
    }
    return low < candidate->count ? candidate->records[low] : NULL;
}
LksStatus lks_managed_order_insert(LksManagedOrder *order, void *item,
    const LksOrderHandle **out_handle)
{
    const LksOrderHandle *upper;
    LksStatus status;
    if (out_handle) *out_handle = NULL;
    if (!order || !item || !out_handle) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->active) return LKS_STATUS_REENTRANT;
    order->active = 1;
    upper = v4_managed_bound(order, item, 1);
    /* All comparisons finish before the explicit core begins preparation/commit. */
    status = upper ? lks_order_insert_before(order->core, upper, item, out_handle) :
        lks_order_insert_back(order->core, item, out_handle);
    order->active = 0;
    return status;
}
LksStatus lks_managed_order_locate(LksManagedOrder *order, const void *query,
    const LksOrderHandle **out_predecessor, const LksOrderHandle **out_equal,
    const LksOrderHandle **out_successor)
{
    const LksOrderHandle *lower, *upper;
    if (out_predecessor) *out_predecessor = NULL;
    if (out_equal) *out_equal = NULL;
    if (out_successor) *out_successor = NULL;
    if (!order || !query || !out_predecessor || !out_equal || !out_successor ||
        out_predecessor == out_equal || out_predecessor == out_successor ||
        out_equal == out_successor) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->active) return LKS_STATUS_REENTRANT;
    order->active = 1;
    lower = v4_managed_bound(order, query, 0);
    upper = v4_managed_bound(order, query, 1);
    *out_predecessor = lower ? lks_order_previous(lower) : lks_order_last(order->core);
    if (lower && v4_managed_compare_item(order, lower->item, query) == 0) *out_equal = lower;
    *out_successor = upper;
    order->active = 0;
    return LKS_STATUS_OK;
}
LksStatus lks_managed_order_remove(LksManagedOrder *order,
    const LksOrderHandle *handle, void **out_item)
{
    if (out_item) *out_item = NULL;
    if (!order) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->active) return LKS_STATUS_REENTRANT;
    return lks_order_remove(order->core, handle, out_item);
}
const LksOrderHandle *lks_managed_order_first(const LksManagedOrder *order)
{ return order && !order->active ? lks_order_first(order->core) : NULL; }
const LksOrderHandle *lks_managed_order_last(const LksManagedOrder *order)
{ return order && !order->active ? lks_order_last(order->core) : NULL; }
LksStatus lks_managed_order_compare(const LksManagedOrder *order,
    const LksOrderHandle *left, const LksOrderHandle *right, int *out_order)
{
    if (out_order) *out_order = 0;
    if (!order) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->active) return LKS_STATUS_REENTRANT;
    return lks_order_compare(order->core, left, right, out_order);
}
LksStatus lks_managed_order_cursor_create(const LksManagedOrder *order, int reverse,
    LksOrderCursor **out_cursor)
{
    if (out_cursor) *out_cursor = NULL;
    if (!order) return LKS_STATUS_INVALID_ARGUMENT;
    if (order->active) return LKS_STATUS_REENTRANT;
    return lks_order_cursor_create(order->core, reverse, out_cursor);
}
/* End production source: src/managed_order.c */

/* Begin production source: src/snapshot.c */
/* bundled include: lks_snapshot_internal.h */
/* bundled include: lks_alloc_internal.h */
#include <string.h>
#if defined(_MSC_VER)
#include <intrin.h>
struct LksSourceMarker { volatile long refs; };
#define SNAP_REF_MAX ((size_t)LONG_MAX)
#else
#include <stdatomic.h>
struct LksSourceMarker { atomic_size_t refs; };
#define SNAP_REF_MAX SIZE_MAX
#endif

static LksSourceMarker *snap_marker_new(void)
{
    LksSourceMarker *m = (LksSourceMarker *)lks_alloc(sizeof(*m));
    if (m) {
#if defined(_MSC_VER)
        m->refs = 2;
#else
        atomic_init(&m->refs, 2);
#endif
    }
    return m;
}
static int snap_marker_retain(LksSourceMarker *m)
{
#if defined(_MSC_VER)
    long old = _InterlockedCompareExchange(&m->refs, 0, 0);
    for (;;) {
        long found;
        if ((size_t)old == SNAP_REF_MAX) return 0;
        found = _InterlockedCompareExchange(&m->refs, old + 1, old);
        if (found == old) return 1;
        old = found;
    }
#else
    size_t old = atomic_load_explicit(&m->refs, memory_order_relaxed);
    do { if (old == SNAP_REF_MAX) return 0; }
    while (!atomic_compare_exchange_weak_explicit(&m->refs, &old, old + 1,
        memory_order_relaxed, memory_order_relaxed));
    return 1;
#endif
}
void lks_source_marker_release(LksSourceMarker *m)
{
    if (!m) return;
#if defined(_MSC_VER)
    if (_InterlockedDecrement(&m->refs) == 0) lks_free(m);
#else
    if (atomic_fetch_sub_explicit(&m->refs, 1, memory_order_acq_rel) == 1) lks_free(m);
#endif
}
#ifdef LKS_ENABLE_ALLOC_DIAGNOSTICS
void lks_source_marker_test_refs(LksSourceMarker *m, size_t refs)
{
#if defined(_MSC_VER)
    (void)_InterlockedExchange(&m->refs, (long)refs);
#else
    atomic_store_explicit(&m->refs, refs, memory_order_relaxed);
#endif
}
#endif

void lks_snapshot_destroy(LksSnapshot *s)
{
    if (!s) return;
    lks_source_marker_release(s->marker);
    lks_free(s->associations); lks_free(s);
}
LksStatus lks_snapshot_new(size_t count, const void *domain, size_t domain_size,
    LksSnapshot **out)
{
    LksSnapshot *s;
    *out = NULL;
    /* Reserve arithmetic for caller-buffer wire/key queries as well. */
    if (!domain || !domain_size || domain_size > UINT32_MAX ||
        domain_size > (SIZE_MAX-22)/2 || count > UINT64_MAX ||
        count > SIZE_MAX/sizeof(LksSnapshotRow) ||
        domain_size > SIZE_MAX-24 || count > (SIZE_MAX-24-domain_size)/8)
        return LKS_STATUS_INVALID_ARGUMENT;
    if (domain_size > SIZE_MAX-sizeof(*s) ||
        count > (SIZE_MAX-sizeof(*s)-domain_size)/sizeof(LksSnapshotRow))
        return LKS_STATUS_INVALID_ARGUMENT;
    s = (LksSnapshot *)lks_alloc(sizeof(*s)+count*sizeof(LksSnapshotRow)+domain_size);
    if (!s) return LKS_STATUS_OUT_OF_MEMORY;
    memset(s, 0, sizeof(*s)); s->count = count; s->namespace_size = domain_size;
    s->rows = count ? (LksSnapshotRow *)(s+1) : NULL;
    s->namespace_data = (unsigned char *)(s+1)+count*sizeof(LksSnapshotRow);
    memcpy(s->namespace_data, domain, domain_size);
    *out = s; return LKS_STATUS_OK;
}

static LksStatus snap_append(LksSnapshot *s, size_t row, const void *data, size_t size)
{
    size_t need, limit = SIZE_MAX-24-s->namespace_size-8*s->count;
    if ((size && !data) || size > UINT64_MAX || size > limit-s->association_size)
        return LKS_STATUS_INVALID_ARGUMENT;
    need = s->association_size + size;
    if (need > s->association_capacity) {
        size_t cap = s->association_capacity ? s->association_capacity : 64;
        unsigned char *p;
        if (cap > limit) cap = need;
        while (cap < need) {
            if (cap > limit/2) { cap = need; break; }
            cap *= 2;
        }
        p = (unsigned char *)lks_realloc(s->associations, cap);
        if (!p) return LKS_STATUS_OUT_OF_MEMORY;
        s->associations = p; s->association_capacity = cap;
    }
    s->rows[row].end = need;
    if (size) memcpy(s->associations+s->association_size, data, size);
    s->association_size = need; return LKS_STATUS_OK;
}
LksStatus lks_snapshot_capture_sequence(size_t count, LksSnapshotNextItem next,
    void *iterator, int *busy, LksSourceMarker **marker, uint64_t revision,
    const LksSnapshotOptions *options, LksSnapshot **out)
{
    LksSnapshot *s; LksStatus status; size_t row;
    LksSnapshotOptions descriptor;
    if (out) *out = NULL;
    if (!options || !out) return LKS_STATUS_INVALID_ARGUMENT;
    if (*busy) return LKS_STATUS_REENTRANT;
    descriptor = *options; options = &descriptor;
    status = lks_snapshot_new(count, options->namespace_data, options->namespace_size, &s);
    if (status != LKS_STATUS_OK) return status;
    for (row = 0; row < count; ++row) {
        void *item = next(iterator); const void *data = NULL; size_t size = 0;
        if (options->association) {
            *busy = 1;
            status = options->association(item, (uint64_t)row, options->context, &data, &size);
            *busy = 0;
            if (status != LKS_STATUS_OK) goto fail;
        }
        status = snap_append(s, row, data, size);
        if (status != LKS_STATUS_OK) goto fail;
    }
    /* Release geometric growth slack before publication. Failure remains a
     * capture failure: no provenance is committed and no partial view escapes. */
    if (s->association_capacity != s->association_size) {
        unsigned char *exact = (unsigned char *)lks_realloc(s->associations, s->association_size);
        if (!exact) { status = LKS_STATUS_OUT_OF_MEMORY; goto fail; }
        s->associations = exact; s->association_capacity = s->association_size;
    }
    /* Commit provenance only after every row is ready. */
    if (*marker) {
        if (!snap_marker_retain(*marker)) { status = LKS_STATUS_CAPACITY_LIMIT; goto fail; }
        s->marker = *marker;
    } else {
        s->marker = snap_marker_new();
        if (!s->marker) { status = LKS_STATUS_OUT_OF_MEMORY; goto fail; }
        *marker = s->marker;
    }
    s->revision = revision; *out = s; return LKS_STATUS_OK;
fail:
    lks_snapshot_destroy(s); return status;
}
typedef struct SnapLiveIterator { LksOrderBlock *block; size_t local; } SnapLiveIterator;
static void *snap_live_next(void *context)
{
    SnapLiveIterator *it = (SnapLiveIterator *)context;
    void *item = it->block->records[it->local++]->item;
    if (it->local == it->block->count) { it->block = it->block->next; it->local = 0; }
    return item;
}
LksStatus lks_order_snapshot_capture(LksOrder *o, const LksSnapshotOptions *options,
    LksSnapshot **out)
{
    SnapLiveIterator it;
    if (out) *out = NULL;
    if (!o || !out) return LKS_STATUS_INVALID_ARGUMENT;
    it.block = o->first; it.local = 0;
    return lks_snapshot_capture_sequence(o->count, snap_live_next, &it,
        &o->callback_active, &o->source_marker, o->revision, options, out);
}
LksStatus lks_managed_order_snapshot_capture(LksManagedOrder *o,
    const LksSnapshotOptions *options, LksSnapshot **out)
{
    LksStatus status;
    if (out) *out = NULL;
    if (!o || !out) return LKS_STATUS_INVALID_ARGUMENT;
    if (o->active) return LKS_STATUS_REENTRANT;
    o->active = 1; status = lks_order_snapshot_capture(o->core, options, out);
    o->active = 0; return status;
}
int lks_order_snapshot_is_current(const LksOrder *o, const LksSnapshot *s)
{ return o && s && !o->callback_active && s->marker &&
    o->source_marker == s->marker && o->revision == s->revision; }
int lks_managed_order_snapshot_is_current(const LksManagedOrder *o, const LksSnapshot *s)
{ return o && !o->active && lks_order_snapshot_is_current(o->core, s); }
size_t lks_snapshot_count(const LksSnapshot *s) { return s ? s->count : 0; }
LksStatus lks_snapshot_namespace(const LksSnapshot *s, const void **data, size_t *size)
{
    if (data) *data = NULL;
    if (size) *size = 0;
    if (!s || !data || !size) return LKS_STATUS_INVALID_ARGUMENT;
    *data = s->namespace_data; *size = s->namespace_size; return LKS_STATUS_OK;
}
LksStatus lks_snapshot_association(const LksSnapshot *s, size_t row,
    const void **data, size_t *size)
{
    if (data) *data = NULL;
    if (size) *size = 0;
    if (!s || !data || !size || row >= s->count) return LKS_STATUS_INVALID_ARGUMENT;
    *size = lks_snapshot_row_size(s, row);
    *data = *size ? s->associations+lks_snapshot_row_offset(s, row) : NULL;
    return LKS_STATUS_OK;
}
/* End production source: src/snapshot.c */

/* Begin production source: src/snapshot_key.c */
/* bundled include: lks_snapshot_internal.h */
#include <string.h>
static const char snap_hex[] = "0123456789abcdef";
static int snap_nibble(char c)
{ return c >= '0' && c <= '9' ? c-'0' : c >= 'a' && c <= 'f' ? c-'a'+10 : -1; }
size_t lks_snapshot_key_length(const LksSnapshot *s)
{ return s ? 21+2*s->namespace_size : 0; }
LksStatus lks_snapshot_key_format(const LksSnapshot *s, size_t row,
    char *buffer, size_t buffer_size)
{
    size_t i, at = 4; uint64_t ordinal = (uint64_t)row;
    if (!s || !buffer || row >= s->count) return LKS_STATUS_INVALID_ARGUMENT;
    if (buffer_size <= lks_snapshot_key_length(s)) return LKS_STATUS_BUFFER_TOO_SMALL;
    memcpy(buffer, "LS1.", 4);
    for (i = 0; i < s->namespace_size; ++i) {
        buffer[at++] = snap_hex[s->namespace_data[i] >> 4];
        buffer[at++] = snap_hex[s->namespace_data[i] & 15];
    }
    buffer[at++] = '.';
    for (i = 0; i < 16; ++i) buffer[at++] = snap_hex[(ordinal >> (60-4*i)) & 15];
    buffer[at] = '\0'; return LKS_STATUS_OK;
}
static LksStatus snap_key_parse(const char *key, size_t *domain_size, uint64_t *ordinal)
{
    const char *p; size_t n = 0, i; uint64_t value = 0;
    if (!key || strncmp(key, "LS1.", 4)) return LKS_STATUS_INVALID_ARGUMENT;
    p = key+4;
    while (*p && *p != '.') {
        if (snap_nibble(*p) < 0 || n == SIZE_MAX) return LKS_STATUS_INVALID_ARGUMENT;
        ++p; ++n;
    }
    if (!n || n%2 || n/2 > UINT32_MAX || *p != '.') return LKS_STATUS_INVALID_ARGUMENT;
    ++p;
    for (i = 0; i < 16; ++i) {
        int digit = snap_nibble(*p);
        if (digit < 0) return LKS_STATUS_INVALID_ARGUMENT;
        value = (value << 4) | (unsigned)digit; ++p;
    }
    if (*p) return LKS_STATUS_INVALID_ARGUMENT;
    *domain_size = n; *ordinal = value; return LKS_STATUS_OK;
}
LksStatus lks_snapshot_key_validate(const char *key)
{ size_t n; uint64_t value; return snap_key_parse(key, &n, &value); }
LksStatus lks_snapshot_key_compare(const char *left, const char *right, int *out)
{
    size_t a, b; uint64_t x, y; LksStatus status;
    if (out) *out = 0;
    if (!out) return LKS_STATUS_INVALID_ARGUMENT;
    status = snap_key_parse(left, &a, &x); if (status != LKS_STATUS_OK) return status;
    status = snap_key_parse(right, &b, &y); if (status != LKS_STATUS_OK) return status;
    if (a != b || memcmp(left+4, right+4, a)) return LKS_STATUS_DOMAIN_MISMATCH;
    *out = (x > y)-(x < y); return LKS_STATUS_OK;
}
/* End production source: src/snapshot_key.c */

/* Begin production source: src/snapshot_wire.c */
/* bundled include: lks_snapshot_internal.h */
/* bundled include: lks_alloc_internal.h */
#include <string.h>
_Static_assert(CHAR_BIT == 8, "snapshot wire requires eight-bit bytes");
/* Fixed-width portable shifts, with no alignment or host-byte-order premise. */
static uint64_t snap_be_read(const unsigned char *p, size_t width)
{
    uint32_t high = ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];
    if (width == 4) return high;
    uint32_t low = ((uint32_t)p[4]<<24)|((uint32_t)p[5]<<16)|((uint32_t)p[6]<<8)|p[7];
    return ((uint64_t)high<<32)|low;
}
static void snap_be_write(unsigned char *p, uint64_t v, size_t width)
{
    if (width == 8) {
        p[0]=(unsigned char)(v>>56); p[1]=(unsigned char)(v>>48);
        p[2]=(unsigned char)(v>>40); p[3]=(unsigned char)(v>>32);
        p+=4;
    }
    p[0]=(unsigned char)(v>>24); p[1]=(unsigned char)(v>>16);
    p[2]=(unsigned char)(v>>8); p[3]=(unsigned char)v;
}

size_t lks_snapshot_serialized_size(const LksSnapshot *s)
{ return s ? 24+s->namespace_size+8*s->count+s->association_size : 0; }
LksStatus lks_snapshot_serialize(const LksSnapshot *s, void *buffer, size_t size)
{
    unsigned char *p = (unsigned char *)buffer; size_t i, offset = 0;
    if (!s || !buffer) return LKS_STATUS_INVALID_ARGUMENT;
    if (size < lks_snapshot_serialized_size(s)) return LKS_STATUS_BUFFER_TOO_SMALL;
    memcpy(p, "LKS4SNP1", 8); snap_be_write(p+8, 0, 4);
    snap_be_write(p+12, s->namespace_size, 4); snap_be_write(p+16, s->count, 8);
    p += 24; memcpy(p, s->namespace_data, s->namespace_size); p += s->namespace_size;
    for (i = 0; i < s->count; ++i) {
        size_t end = s->rows[i].end, n = end-offset;
        snap_be_write(p, n, 8); p += 8;
        if (n) memcpy(p, s->associations+offset, n);
        p += n; offset = end;
    }
    return LKS_STATUS_OK;
}
LksStatus lks_snapshot_deserialize(const void *buffer, size_t size, LksSnapshot **out)
{
    const unsigned char *p = (const unsigned char *)buffer;
    size_t domain, count, at, i, total = 0; uint64_t rows;
    LksSnapshot *s; LksStatus status;
    if (out) *out = NULL;
    if (!out || !p || size < 24) return LKS_STATUS_INVALID_ARGUMENT;
    if (memcmp(p, "LKS4SNP1", 8) || snap_be_read(p+8, 4)) return LKS_STATUS_INVALID_ARGUMENT;
    domain = (size_t)snap_be_read(p+12, 4); rows = snap_be_read(p+16, 8);
    if (!domain || domain > size-24 || rows > SIZE_MAX) return LKS_STATUS_INVALID_ARGUMENT;
    at = 24+domain; count = (size_t)rows;
    if (count > (size-at)/8 || count > SIZE_MAX/sizeof(LksSnapshotRow))
        return LKS_STATUS_INVALID_ARGUMENT;
    /* Complete counting/validation pass before any speculative allocation. */
    for (i = 0; i < count; ++i) {
        uint64_t length;
        if (size-at < 8) return LKS_STATUS_INVALID_ARGUMENT;
        length = snap_be_read(p+at, 8); at += 8;
        if (length > SIZE_MAX || length > size-at || length > SIZE_MAX-total)
            return LKS_STATUS_INVALID_ARGUMENT;
        at += (size_t)length; total += (size_t)length;
    }
    if (at != size) return LKS_STATUS_INVALID_ARGUMENT;
    status = lks_snapshot_new(count, p+24, domain, &s);
    if (status != LKS_STATUS_OK) return status;
    if (total) {
        s->associations = (unsigned char *)lks_alloc(total);
        if (!s->associations) { lks_snapshot_destroy(s); return LKS_STATUS_OUT_OF_MEMORY; }
    }
    s->association_capacity = total; s->association_size = total;
    at = 24+domain; total = 0;
    for (i = 0; i < count; ++i) {
        size_t n = (size_t)snap_be_read(p+at, 8); at += 8;
        s->rows[i].end = total+n;
        if (n) memcpy(s->associations+total, p+at, n);
        total += n; at += n;
    }
    *out = s; return LKS_STATUS_OK;
}
/* End production source: src/snapshot_wire.c */

/* Begin production source: src/snapshot_restore.c */
/* bundled include: lks_legacy_internal.h */
/* bundled include: lks_snapshot_internal.h */
/* bundled include: lks_alloc_internal.h */

LksStatus lks_snapshot_restore_order(const LksSnapshot *s,
    LksSnapshotResolveFn resolve, void *context, LksOrder **out)
{
    void **items = NULL; size_t i, offset = 0; LksStatus status;
    if (out) *out = NULL;
    if (!s || !out || (s->count && !resolve) || s->count > SIZE_MAX/sizeof(*items))
        return LKS_STATUS_INVALID_ARGUMENT;
    if (s->count) {
        items = (void **)lks_alloc(s->count*sizeof(*items));
        if (!items) return LKS_STATUS_OUT_OF_MEMORY;
    }
    for (i = 0; i < s->count; ++i) {
        size_t end = s->rows[i].end, size = end-offset;
        const void *data = size ? s->associations+offset : NULL;
        items[i] = NULL;
        status = resolve(data, size, (uint64_t)i, context, &items[i]);
        if (status != LKS_STATUS_OK) goto done;
        if (!items[i]) { status = LKS_STATUS_INVALID_ARGUMENT; goto done; }
        offset = end;
    }
    status = lks_order_bulk_build(items, s->count, out);
done:
    lks_free(items); return status;
}
typedef struct SnapLegacyRow { LksPath *path; void *item; } SnapLegacyRow;
static int snap_legacy_compare(const void *left, const void *right, void *context)
{
    const SnapLegacyRow *a = (const SnapLegacyRow *)left, *b = (const SnapLegacyRow *)right;
    int order = 0;
    (void)context; (void)lks_path_compare(a->path, b->path, &order); return order;
}
LksStatus lks_order_import_v3_lk1(const LksV3Lk1ImportEntry *entries,
    size_t count, LksOrder **out)
{
    SnapLegacyRow *rows = NULL; void **sorted = NULL; size_t i, parsed = 0;
    LksStatus status = LKS_STATUS_OUT_OF_MEMORY;
    if (out) *out = NULL;
    if (!out || (count && !entries) || count > SIZE_MAX/sizeof(*rows) ||
        count > SIZE_MAX/sizeof(*sorted)) return LKS_STATUS_INVALID_ARGUMENT;
    if (!count) return lks_order_bulk_build(NULL, 0, out);
    rows = (SnapLegacyRow *)lks_alloc(count*sizeof(*rows));
    sorted = (void **)lks_alloc(count*sizeof(*sorted));
    if (!rows || !sorted) goto done;
    for (i = 0; i < count; ++i) {
        if (!entries[i].key || !entries[i].item) { status = LKS_STATUS_INVALID_ARGUMENT; goto done; }
        status = lks_path_order_key_parse(entries[i].key, &rows[i].path);
        if (status != LKS_STATUS_OK) goto done;
        ++parsed; rows[i].item = entries[i].item; sorted[i] = &rows[i];
    }
    status = lks_sort(sorted, count, snap_legacy_compare, NULL);
    if (status != LKS_STATUS_OK) goto done;
    for (i = 1; i < count; ++i) {
        if (!snap_legacy_compare(sorted[i-1], sorted[i], NULL)) {
            status = LKS_STATUS_ALREADY_EXISTS; goto done;
        }
    }
    for (i = 0; i < count; ++i) sorted[i] = ((SnapLegacyRow *)sorted[i])->item;
    status = lks_order_bulk_build(sorted, count, out);
done:
    for (i = 0; i < parsed; ++i) lks_path_destroy(rows[i].path);
    lks_free(sorted); lks_free(rows); return status;
}
/* End production source: src/snapshot_restore.c */

/* Begin production source: src/order_bulk.c */
/* bundled include: lks_order_internal.h */
/* bundled include: lks_alloc_internal.h */
#include <string.h>

/* Consume the threaded sequence in order to construct a balanced index without
 * arrays of blocks, per-resident searches or rotations. Stack is O(log blocks). */
static LksOrderBlock *snap_bulk_index(LksOrderBlock **cursor, size_t count)
{
    LksOrderBlock *left, *root, *right; int a, b;
    if (!count) return NULL;
    left = snap_bulk_index(cursor, count/2);
    root = *cursor; *cursor = root->next;
    right = snap_bulk_index(cursor, count-count/2-1);
    root->left = left; root->right = right;
    if (left) left->parent = root;
    if (right) right->parent = root;
    a = left ? left->height : 0; b = right ? right->height : 0;
    root->height = 1+(a > b ? a : b); root->subtree_blocks = count;
    return root;
}
LksStatus lks_order_bulk_build(void *const *items, size_t count, LksOrder **out)
{
    LksOrder *o; LksOrderBlock *cursor; size_t blocks, base, extra, i, row = 0;
    *out = NULL;
    if ((count && !items) || count > UINT64_MAX) return LKS_STATUS_INVALID_ARGUMENT;
    o = lks_order_create(); if (!o) return LKS_STATUS_OUT_OF_MEMORY;
    blocks = count/LKS_ORDER_BLOCK_CAPACITY+(count%LKS_ORDER_BLOCK_CAPACITY != 0);
    base = blocks ? count/blocks : 0; extra = blocks ? count%blocks : 0;
    for (i = 0; i < blocks; ++i) {
        LksOrderBlock *b = (LksOrderBlock *)lks_alloc(sizeof(*b));
        size_t j, n = base+(i < extra);
        if (!b) goto oom;
        memset(b, 0, sizeof(*b)); b->owner = o; b->tag = ((uint64_t)i+1)*(UINT64_MAX/((uint64_t)blocks+1)); b->previous = o->last;
        if (o->last) o->last->next = b; else o->first = b;
        o->last = b; ++o->blocks;
        for (j = 0; j < n; ++j, ++row) {
            LksOrderHandle *h;
            if (!items[row]) { lks_order_destroy(o); return LKS_STATUS_INVALID_ARGUMENT; }
            h = (LksOrderHandle *)lks_alloc(sizeof(*h));
            if (!h) goto oom;
            h->block = b; h->local = j; h->item = items[row];
            b->records[b->count++] = h; ++o->count;
        }
    }
    cursor = o->first; o->root = snap_bulk_index(&cursor, blocks);
    *out = o; return LKS_STATUS_OK;
oom:
    lks_order_destroy(o); return LKS_STATUS_OUT_OF_MEMORY;
}
/* End production source: src/order_bulk.c */

/* Begin production source: src/immutable_group.c */
/* bundled include: lks_immutable_group_internal.h */
/* bundled include: lks_snapshot_internal.h */
/* bundled include: lks_alloc_internal.h */
/* bundled include: lks_sort_internal.h */
#include <string.h>

static LksGroup *ig_new(size_t count)
{
    LksGroup *g;
    if (count > SIZE_MAX/sizeof(void *)) return NULL;
    g = (LksGroup *)lks_alloc(sizeof(*g));
    if (g) { memset(g, 0, sizeof(*g)); g->count = count; }
    return g;
}
void lks_group_destroy(LksGroup *g)
{
    if (!g || g->busy) return;
    lks_source_marker_release(g->marker); lks_free(g->items); lks_free(g);
}
size_t lks_group_size(const LksGroup *g)
{ return g && !g->busy ? g->count : 0; }
void *lks_group_item_at(const LksGroup *g, size_t at)
{ return g && !g->busy && at < g->count ? g->items[at] : NULL; }
LksStatus lks_group_build(void *const *items, size_t count,
    const LksComparator *comparator, LksGroup **out)
{
    LksGroup *g; LksStatus status; size_t i; LksComparator descriptor;
    if (out) *out = NULL;
    if (!out || !comparator || !comparator->compare || (count && !items) ||
        count > SIZE_MAX/sizeof(void *)) return LKS_STATUS_INVALID_ARGUMENT;
    for (i = 0; i < count; ++i) if (!items[i]) return LKS_STATUS_INVALID_ARGUMENT;
    descriptor = *comparator;
    g = ig_new(count); if (!g) return LKS_STATUS_OUT_OF_MEMORY;
    status = lks_stable_sort_copy(items, count, &descriptor, &g->items);
    if (status != LKS_STATUS_OK) { lks_group_destroy(g); return status; }
    *out = g; return LKS_STATUS_OK;
}
LksStatus lks_group_merge(const LksGroup *base,
    const LksGroup *incoming, const LksComparator *comparator,
    LksGroup **out)
{
    LksGroup *g, *a = (LksGroup *)base, *b = (LksGroup *)incoming;
    size_t count; LksComparator descriptor;
    if (out) *out = NULL;
    if (!a || !b || !out || !comparator || !comparator->compare) return LKS_STATUS_INVALID_ARGUMENT;
    if (a->busy || b->busy) return LKS_STATUS_REENTRANT;
    if (a->count > SIZE_MAX-b->count || a->count+b->count > SIZE_MAX/sizeof(void *))
        return LKS_STATUS_INVALID_ARGUMENT;
    count = a->count+b->count; descriptor = *comparator;
    g = ig_new(count); if (!g) return LKS_STATUS_OUT_OF_MEMORY;
    if (count) {
        g->items = (void **)lks_alloc(count*sizeof(*g->items));
        if (!g->items) { lks_group_destroy(g); return LKS_STATUS_OUT_OF_MEMORY; }
    }
    a->busy = b->busy = 1;
    lks_merge_sorted_pointers(a->items, a->count, b->items, b->count, &descriptor, g->items);
    a->busy = b->busy = 0; *out = g; return LKS_STATUS_OK;
}
void lks_group_batch_destroy(LksGroupBatch *b)
{
    size_t i;
    if (!b || b->busy) return;
    /* A borrowed chunk may currently be executing an association callback. */
    for (i = 0; i < b->group_count; ++i) if (b->groups[i]->busy) return;
    for (i = 0; i < b->group_count; ++i) lks_group_destroy(b->groups[i]);
    lks_free(b->groups); lks_free(b);
}
LksStatus lks_group_batch_build(void *const *items, size_t count,
    size_t group_size, const LksComparator *comparator, LksGroupBatch **out)
{
    LksGroupBatch *b; size_t groups, i, at = 0; LksStatus status;
    LksComparator descriptor;
    if (out) *out = NULL;
    if (!out || !group_size || !comparator || !comparator->compare || (count && !items) ||
        count > SIZE_MAX/sizeof(void *)) return LKS_STATUS_INVALID_ARGUMENT;
    descriptor = *comparator; groups = count/group_size+(count%group_size != 0);
    if (groups > SIZE_MAX/sizeof(LksGroup *)) return LKS_STATUS_INVALID_ARGUMENT;
    b = (LksGroupBatch *)lks_alloc(sizeof(*b));
    if (!b) return LKS_STATUS_OUT_OF_MEMORY;
    memset(b, 0, sizeof(*b)); b->count = count; b->group_size = group_size;
    if (groups) {
        b->groups = (LksGroup **)lks_alloc(groups*sizeof(*b->groups));
        if (!b->groups) { lks_free(b); return LKS_STATUS_OUT_OF_MEMORY; }
    }
    for (i = 0; i < groups; ++i) {
        size_t n = count-at < group_size ? count-at : group_size;
        status = lks_group_build(items+at, n, &descriptor, &b->groups[i]);
        if (status != LKS_STATUS_OK) { lks_group_batch_destroy(b); return status; }
        ++b->group_count; at += n;
    }
    *out = b; return LKS_STATUS_OK;
}
size_t lks_group_batch_size(const LksGroupBatch *b)
{ return b && !b->busy ? b->count : 0; }
size_t lks_group_batch_group_count(const LksGroupBatch *b)
{ return b && !b->busy ? b->group_count : 0; }
size_t lks_group_batch_group_size(const LksGroupBatch *b)
{ return b && !b->busy ? b->group_size : 0; }
const LksGroup *lks_group_batch_group_at(const LksGroupBatch *b, size_t i)
{ return b && !b->busy && i < b->group_count ? b->groups[i] : NULL; }
LksStatus lks_group_batch_merge_all(const LksGroupBatch *batch,
    const LksComparator *comparator, LksGroup **out)
{
    LksGroupBatch *b = (LksGroupBatch *)batch;
    LksGroup *g; void **scratch = NULL, **from, **to;
    size_t i, at = 0, width; LksComparator descriptor;
    if (out) *out = NULL;
    if (!b || !out || !comparator || !comparator->compare) return LKS_STATUS_INVALID_ARGUMENT;
    if (b->busy) return LKS_STATUS_REENTRANT;
    for (i = 0; i < b->group_count; ++i) if (b->groups[i]->busy) return LKS_STATUS_REENTRANT;
    descriptor = *comparator; g = ig_new(b->count); if (!g) return LKS_STATUS_OUT_OF_MEMORY;
    if (b->count) {
        g->items = (void **)lks_alloc(b->count*sizeof(*g->items));
        if (!g->items) goto oom;
    }
    if (b->group_count > 1) {
        scratch = (void **)lks_alloc(b->count*sizeof(*scratch));
        if (!scratch) goto oom;
    }
    for (i = 0; i < b->group_count; ++i) {
        memcpy(g->items+at, b->groups[i]->items, b->groups[i]->count*sizeof(*g->items));
        at += b->groups[i]->count;
    }
    b->busy = 1;
    for (i = 0; i < b->group_count; ++i) b->groups[i]->busy = 1;
    from = g->items; to = scratch; width = b->group_size;
    while (width < b->count) {
        for (at = 0; at < b->count;) {
            size_t left = b->count-at < width ? b->count-at : width;
            size_t remain = b->count-at-left, right = remain < width ? remain : width;
            lks_merge_sorted_pointers(from+at, left, from+at+left, right, &descriptor, to+at);
            at += left+right;
        }
        { void **swap = from; from = to; to = swap; }
        if (width >= b->count-width) break;
        width *= 2;
    }
    if (from != g->items) memcpy(g->items, from, b->count*sizeof(*g->items));
    for (i = 0; i < b->group_count; ++i) b->groups[i]->busy = 0;
    b->busy = 0; lks_free(scratch); *out = g; return LKS_STATUS_OK;
oom:
    lks_free(scratch); lks_group_destroy(g); return LKS_STATUS_OUT_OF_MEMORY;
}
typedef struct IgIterator { const LksGroup *group; size_t index; } IgIterator;
static void *ig_next(void *context)
{ IgIterator *it = (IgIterator *)context; return it->group->items[it->index++]; }
LksStatus lks_group_snapshot_capture(const LksGroup *group,
    const LksSnapshotOptions *options, LksSnapshot **out)
{
    LksGroup *g = (LksGroup *)group; IgIterator it;
    if (out) *out = NULL;
    if (!g || !out) return LKS_STATUS_INVALID_ARGUMENT;
    it.group = g; it.index = 0;
    return lks_snapshot_capture_sequence(g->count, ig_next, &it, &g->busy,
        &g->marker, 0, options, out);
}
int lks_group_snapshot_is_current(const LksGroup *g, const LksSnapshot *s)
{ return g && s && !g->busy && s->marker && g->marker == s->marker && s->revision == 0; }
/* End production source: src/immutable_group.c */

/* Begin production source: src/sort.c */
#include <string.h>
/* bundled include: layerkeysort.h */
/* bundled include: lks_alloc_internal.h */
/* bundled include: lks_sort_internal.h */

void lks_merge_sorted_pointers(void *const *left, size_t left_count,
    void *const *right, size_t right_count, const LksComparator *comparator,
    void **output)
{
    size_t l = 0, r = 0, out = 0;
    /* Taking the left item on equality preserves source order. */
    while (l < left_count && r < right_count) {
        if (comparator->compare(left[l], right[r], comparator->context) <= 0)
            output[out++] = left[l++];
        else
            output[out++] = right[r++];
    }
    while (l < left_count) output[out++] = left[l++];
    while (r < right_count) output[out++] = right[r++];
}

static void stable_sort_range(void **items, void **scratch, size_t begin,
    size_t end, const LksComparator *comparator)
{
    size_t middle;
    if (end - begin < 2) return;
    middle = begin + (end - begin) / 2;
    stable_sort_range(items, scratch, begin, middle, comparator);
    stable_sort_range(items, scratch, middle, end, comparator);
    lks_merge_sorted_pointers(items + begin, middle - begin,
        items + middle, end - middle, comparator, scratch + begin);
    memcpy(items + begin, scratch + begin, (end - begin) * sizeof(*items));
}

LksStatus lks_stable_sort_copy(void *const *items, size_t count,
    const LksComparator *comparator, void ***out_sorted)
{
    void **sorted, **scratch;
    if (out_sorted == NULL) return LKS_STATUS_INVALID_ARGUMENT;
    *out_sorted = NULL;
    if (comparator == NULL || comparator->compare == NULL ||
        (count != 0 && items == NULL)) return LKS_STATUS_INVALID_ARGUMENT;
    if (count == 0) return LKS_STATUS_OK;
    if (count > (size_t)-1 / sizeof(*sorted)) return LKS_STATUS_OUT_OF_MEMORY;
    sorted = (void **)lks_alloc_tagged(count * sizeof(*sorted), LKS_ALLOC_TAG_MERGE_SCRATCH);
    if (sorted == NULL) return LKS_STATUS_OUT_OF_MEMORY;
    scratch = (void **)lks_alloc_tagged(count * sizeof(*scratch), LKS_ALLOC_TAG_MERGE_SCRATCH);
    if (scratch == NULL) { lks_free(sorted); return LKS_STATUS_OUT_OF_MEMORY; }
    memcpy(sorted, items, count * sizeof(*sorted));
    stable_sort_range(sorted, scratch, 0, count, comparator);
    lks_free(scratch);
    *out_sorted = sorted;
    return LKS_STATUS_OK;
}

LksStatus lks_sort(void **items, size_t count, LksCompareFn compare, void *context)
{
    LksComparator comparator;
    void **sorted = NULL;
    LksStatus status;
    if (compare == NULL || (count != 0 && items == NULL))
        return LKS_STATUS_INVALID_ARGUMENT;
    if (count < 2) return LKS_STATUS_OK;
    comparator.compare = compare;
    comparator.context = context;
    status = lks_stable_sort_copy(items, count, &comparator, &sorted);
    if (status != LKS_STATUS_OK) return status;
    /* Commit only after all allocations and comparisons have completed. */
    if (count != 0) memcpy(items, sorted, count * sizeof(*items));
    lks_free(sorted);
    return LKS_STATUS_OK;
}
/* End production source: src/sort.c */
